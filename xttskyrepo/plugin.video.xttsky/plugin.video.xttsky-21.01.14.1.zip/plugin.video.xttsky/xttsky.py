# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import urllib.parse
import urllib.request
from urllib.parse import urlparse
# from urllib.parse import urlencode, quote_plus, unquote_plus
# from urllib.parse import unquote_plus
# from urllib.parse import quote_plus
# import datetime
import html
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import base64
from bs4 import BeautifulSoup, SoupStrainer
import requests
import requests_cache
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
fanart = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
Fanart = 'special://home/addons/'+addon_id+'/resources/images/Fanart.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
FILENAME = "xttsky"
logdata = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzExNTsmIzExNjsmIzEwMTsmIzExNDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA4OyYjMTExOyYjMTAzOyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
dataurl = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzExNTsmIzExNjsmIzEwMTsmIzExNDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
dataxml = "JiM2OTsmIzU4OyYjNDc7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMDk7JiM5OTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTA5OyYjOTk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
def main():
    # datacp()
    insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = decodee(str(r.text))
    # print (rs)
    # print (str(json.loads(rs)['paneurl']))
    # js = str(json.loads(rs)['paneurl'][0]['datalog'])
    js = str(str(json.loads(rs)['keydata'])).strip('[]')
    match=re.compile('(?:\"|\')keylog(?:\"|\')\:\s*(?:\"|\')\>xttsky\<'+keylog+'\>xttsky\<(?:\"|\')').findall(str(js))
    if not match != []:
        hatacpxttmc()
        return playList.clear(exit())
    else: 
        return mainnet()
        # return mainxml()
def mainnet():
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    if __settings__.getSetting("PanelAcKapat") == "false":
        pass
    else:
        r = requests.get(decodee(dataurl), headers=headers)
        r.raise_for_status()
        # print (r.text)
        if '.' in r.text:
            # print (r.text)
            jr = r.json()['data']
            for panelsayisi in range(len(jr)):
                panel = jr[panelsayisi]
                # print (panel)
                group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "logmac(url,macinfo)",str(panel['datalog']),thumbnail,"","",str(panel['datamac']),"","")
        else:
            # rs = decodee((r.text).replace("[", '').replace("]", '').replace("b'", '').replace("'", '').replace(" ", ''))
            rs = decodee(str(r.text))
            # print (rs)
            # print (str(json.loads(rs)['paneurl']))
            # js = str(json.loads(rs)['paneurl'][0]['datalog'])
            js = str(str(json.loads(rs)['data'])).strip('[]')
            # print (js)
            match=re.compile('\{(?:\"|\')\s*datalog\s*(?:\"|\')\s*\:\s*(?:\"|\')\s*(.*?)\s*(?:\"|\')\s*\,\s*(?:\"|\')\s*datamac\s*(?:\"|\')\s*\: \'00\:1(?:A|a)?\:79\:([0-9A-Za-z_\-:]+)\s*(?:\"|\')\s*}').findall(str(js))
            for panelsayisi in range(len(match)):
                # print (match[panelsayisi][0])
                group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "logmac(url,macinfo)",str(match[panelsayisi][0]),thumbnail,"","",str('00:1A:79:' + match[panelsayisi][1]),"","")
                
    if __settings__.getSetting("ListeAcKapat") == "false":
        pass
    else:
        if __settings__.getSetting("panel1onoff") == "true":
            host1 = __settings__.getSetting("host1")
            mac1 = __settings__.getSetting("mac1")
        else:
            host1 = ""
            mac1 = ""
        if __settings__.getSetting("panel2onoff") == "true":
            host2 = __settings__.getSetting("host2")
            mac2 = __settings__.getSetting("mac2")
        else:
            host2 = ""
            mac2 = ""
        if __settings__.getSetting("panel3onoff") == "true":
            host3 = __settings__.getSetting("host3")
            mac3 = __settings__.getSetting("mac3")
        else:
            host3 = ""
            mac3 = ""
        if __settings__.getSetting("panel4onoff") == "true":
            host4 = __settings__.getSetting("host4")
            mac4 = __settings__.getSetting("mac4")
        else:
            host4 = ""
            mac4 = ""
        if __settings__.getSetting("panel5onoff") == "true":
            host5 = __settings__.getSetting("host5")
            mac5 = __settings__.getSetting("mac5")
        else:
            host5 = ""
            mac5 = ""
        if __settings__.getSetting("panel6onoff") == "true":
            host6 = __settings__.getSetting("host6")
            mac6 = __settings__.getSetting("mac6")
        else:
            host6 = ""
            mac6 = ""
        if __settings__.getSetting("panel7onoff") == "true":
            host7 = __settings__.getSetting("host7")
            mac7 = __settings__.getSetting("mac7")
        else:
            host7 = ""
            mac7 = ""
        if __settings__.getSetting("panel8onoff") == "true":
            host8 = __settings__.getSetting("host8")
            mac8 = __settings__.getSetting("mac8")
        else:
            host8 = ""
            mac8 = ""
        if __settings__.getSetting("panel9onoff") == "true":
            host9 = __settings__.getSetting("host9")
            mac9 = __settings__.getSetting("mac9")
        else:
            host9 = ""
            mac9 = ""
        if __settings__.getSetting("panel10onoff") == "true":
            host10 = __settings__.getSetting("host10")
            mac10 = __settings__.getSetting("mac10")
        else:
            host10 = ""
            mac10 = ""
        if __settings__.getSetting("panel11onoff") == "true":
            host11 = __settings__.getSetting("host11")
            mac11 = __settings__.getSetting("mac11")
        else:
            host11 = ""
            mac11 = ""
        if __settings__.getSetting("panel12onoff") == "true":
            host12 = __settings__.getSetting("host12")
            mac12 = __settings__.getSetting("mac12")
        else:
            host12 = ""
            mac12 = ""
        if __settings__.getSetting("panel13onoff") == "true":
            host13 = __settings__.getSetting("host13")
            mac13 = __settings__.getSetting("mac13")
        else:
            host13 = ""
            mac13 = ""
        if __settings__.getSetting("panel14onoff") == "true":
            host14 = __settings__.getSetting("host14")
            mac14 = __settings__.getSetting("mac14")
        else:
            host14 = ""
            mac14 = ""
        if __settings__.getSetting("panel15onoff") == "true":
            host15 = __settings__.getSetting("host15")
            mac15 = __settings__.getSetting("mac15")
        else:
            host15 = ""
            mac15 = ""
        if __settings__.getSetting("panel16onoff") == "true":
            host16 = __settings__.getSetting("host16")
            mac16 = __settings__.getSetting("mac16")
        else:
            host16 = ""
            mac16 = ""
        if __settings__.getSetting("panel17onoff") == "true":
            host17 = __settings__.getSetting("host17")
            mac17 = __settings__.getSetting("mac17")
        else:
            host17 = ""
            mac17 = ""
        if __settings__.getSetting("panel18onoff") == "true":
            host18 = __settings__.getSetting("host18")
            mac18 = __settings__.getSetting("mac18")
        else:
            host18 = ""
            mac18 = ""
        if __settings__.getSetting("panel19onoff") == "true":
            host19 = __settings__.getSetting("host19")
            mac19 = __settings__.getSetting("mac19")
        else:
            host19 = ""
            mac19 = ""
        if __settings__.getSetting("panel20onoff") == "true":
            host20 = __settings__.getSetting("host20")
            mac20 = __settings__.getSetting("mac20")
        else:
            host20 = ""
            mac20 = ""
        
        settingspanel = []
        data = [
        {"datalog": host1, "datamac": mac1},
        {"datalog": host2, "datamac": mac2},
        {"datalog": host3, "datamac": mac3},
        {"datalog": host4, "datamac": mac4},
        {"datalog": host5, "datamac": mac5},
        {"datalog": host6, "datamac": mac6},
        {"datalog": host7, "datamac": mac7},
        {"datalog": host8, "datamac": mac8},
        {"datalog": host9, "datamac": mac9},
        {"datalog": host10, "datamac": mac10},
        {"datalog": host11, "datamac": mac11},
        {"datalog": host12, "datamac": mac12},
        {"datalog": host13, "datamac": mac13},
        {"datalog": host14, "datamac": mac14},
        {"datalog": host15, "datamac": mac15},
        {"datalog": host16, "datamac": mac16},
        {"datalog": host17, "datamac": mac17},
        {"datalog": host18, "datamac": mac18}
        ]
        for panelsayisi in range(len(data)):
            panel = data[panelsayisi]['datalog']
            # print (panel)
            if not data[panelsayisi]['datalog'] != "":
                pass
            else:
                settingspanel.append((data[panelsayisi]))
        if settingspanel == []:
            pass
        else:
            for panelok in range(len(settingspanel)):
                group_title = 'SMART LİSTE  ' + "[B][COLOR red]"+str(panelok+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "logmac(url,macinfo)",str(settingspanel[panelok]['datalog']),thumbnail,"","",str(settingspanel[panelok]['datamac']),"","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def mainxml():
    gf = open(decodee(dataxml), 'r', encoding='utf-8')
    # data = gf.read()
    datacap = json.loads(gf.read())
    # link = link.encode('utf-8', 'ignore')
    data = datacap['paneurl']
    # print (data)
    for panelsayisi in range(len(data)):
        panel = data[panelsayisi]
        # print (panel)
        group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
        thumbnail = images_path + "/xttsmarttv.png"
        xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "logmac(url,macinfo)",str(panel['panelhost']),thumbnail,"","",str(panel['panelmac']),"","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def maintest():
    data = [
ICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9pc3RhbmJ1bDE0NTMuYml6OjgwODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6QTI6ODI6RUIifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9pcHR2dHIxLm5ldDo4MDgwIiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjI4OjdFOjQ3In0sCiAgICB7InBhbmVsaG9zdCI6ICJodHRwOi8vZWxpdDY0LmNvbTo2NDY0IiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjAwOjRFOjVCIn0sCiAgICB7InBhbmVsaG9zdCI6ICJodHRwOi8vY2FydGlwdHYuY29tOjgwODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6MDA6MDg6RDkifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly92aXAuYm1idHYubWU6MTUwMDAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6NkY6NjU6RTQifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9kZGlwdHYubWw6ODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6MDA6RDM6RUEifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly90aXZpeHMuY29tOjgwIiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjFBOjAyOkFEIn0
    ]
    for panelsayisi in range(len(data)):
        panel = data[panelsayisi]
        # print (panel)
        group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
        thumbnail = images_path + "/xttsmarttv.png"
        xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "logmac(url,macinfo)",str(panel['panelhost']),thumbnail,"","",str(panel['panelmac']),"","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def logmac(url,macinfo):
    # print (url,macinfo)
    mac = str(macinfo)
    panelurl = str(url)
    # print ('selam')
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    url = urlparse(url)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + decodee("JiM0NzsmIzExMjsmIzExMTsmIzExNDsmIzExNjsmIzk3OyYjMTA4OyYjNDY7JiMxMTI7JiMxMDQ7JiMxMTI7JiM2MzsmIzk3OyYjOTk7JiMxMTY7JiMxMDU7JiMxMTE7JiMxMTA7JiM2MTsmIzEwNDsmIzk3OyYjMTEwOyYjMTAwOyYjMTE1OyYjMTA0OyYjOTc7JiMxMDc7JiMxMDE7JiMzODsmIzExNjsmIzEyMTsmIzExMjsmIzEwMTsmIzYxOyYjMTE1OyYjMTE2OyYjOTg7JiMzODsmIzExNjsmIzExMTsmIzEwNzsmIzEwMTsmIzExMDsmIzYxOyYjMzg7JiMxMDk7JiM5NzsmIzk5OyYjNjE7") + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + decodee("JiM0NzsmIzExMjsmIzExMTsmIzExNDsmIzExNjsmIzk3OyYjMTA4OyYjNDY7JiMxMTI7JiMxMDQ7JiMxMTI7JiM2MzsmIzExNjsmIzEyMTsmIzExMjsmIzEwMTsmIzYxOyYjMTE1OyYjMTE2OyYjOTg7JiMzODsmIzk3OyYjOTk7JiMxMTY7JiMxMDU7JiMxMTE7JiMxMTA7JiM2MTsmIzEwMzsmIzEwMTsmIzExNjsmIzk1OyYjMTEyOyYjMTE0OyYjMTExOyYjMTAyOyYjMTA1OyYjMTA4OyYjMTAxOw==")
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (cookies)
    # kanalidleritoplama = []
    # account_info = panelurl + "/portal.php?type=account_info&action=get_main_info&mac=" + mac
    # rsaccount = requests.get(account_info, cookies=cookies, headers=headers)
    # macinfo = rsaccount.json()['js']['phone']
    # if not macinfo != 'phone':
        # pass
    # else:
    thumbnaillive = images_path + "/xttsmarttv.png"
    thumbnailvod = images_path + "/xttsine.png"
    xttplaymac(FILENAME,str("LIVE"), "loglive(url,macinfo,cokinfo,headersinfo)",panelurl,thumbnaillive,"","",str(mac),str(default_timezone),str(tokentext))
    xttplaymac(FILENAME,str("VOD"), "xttskyvod(url,macinfo,cokinfo,headersinfo)",panelurl,thumbnailvod,"","",str(mac),str(default_timezone),str(tokentext))
    xbmc.executebuiltin("Container.SetViewMode(500)")
def loglive(url,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    try:
        r = requests.get(tokenurl, cookies=cookies, headers=headers)
        r.raise_for_status()
        jr = r.json()
        # print (jr)
        tokentext = jr['js']['token']
        # print(tokentext)
        cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
        headers = {"Authorization": "Bearer "+tokentext}
        profile = panelurl + "/portal.php?type=stb&action=get_profile"
        rs = requests.get(profile, cookies=cookies, headers=headers)
        # print (rs.text)
        default_timezone = rs.json()['js']['default_timezone']
        # print (default_timezone)
        # print (rs.json()['js']['password'])
        cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
        get_genres = str(url) + "/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml" + str(macinfo)
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        for listeler in rs.json()['js']:
            # print (listeler)
            if  not listeler['id'] != '*':
                pass
            else:
                if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                    if __settings__.getSetting("yetiskinackapat") == "true":
                        idler = listeler['id']
                        title= listeler['title']
                        # print ('selam1 3d ',title)
                        thumbnaillive = images_path + "/xttmctv.png"
                        xttplaymac(FILENAME,title, "x18loglivetopla(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
                    else:
                        pass
                else:
                    idler = listeler['id']
                    title= listeler['title']
                    # print ('selam 3d ',title)
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "loglivetopla(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
    except: 
        return loglive2(url,macinfo,cokinfo,headersinfo)

    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def loglivetopla(url,fix,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (url,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
    # rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # sayfa = rs.json()['js']['total_items']
    # print ('sayfalama  :', sayfa)
    # for pagenext in range(1, int(sayfa+1)):
    for pagenext in range(1, 51):
        get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        playlistgenre = rs.json()['js']['data']
        # print (playlistgenre)
        for listeler in playlistgenre:
            # print (listeler)
            name = listeler['name']
            # print (name)
            cmd = listeler['cmd']
            # print (cmd)
            logo = listeler['logo']
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            xttplaymac(FILENAME,name, "stremxttskylive(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
def x18loglivetopla(url,fix,macinfo,cokinfo,headersinfo):
    # print ('gelen selam',url,fix,macinfo,cokinfo,headersinfo)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        # print ('gelen selam1')
        __settings__.openSettings()
        if datalog == "":
            # print ('gelen selam2')
            return playList.clear(exit())
    else:
        # print ('gelen selam3')
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            mac = macinfo
            headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            panelurl = url
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
            # try:
            r = requests.get(tokenurl, cookies=cookies, headers=headers)
            r.raise_for_status()
            jr = r.json()
            # print (jr)
            tokentext = jr['js']['token']
            # print(tokentext)
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            headers = {"Authorization": "Bearer "+tokentext}
            profile = panelurl + "/portal.php?type=stb&action=get_profile"
            rs = requests.get(profile, cookies=cookies, headers=headers)
            # print (rs.text)
            default_timezone = rs.json()['js']['default_timezone']
            # print (default_timezone)
            # print (rs.json()['js']['password'])
            cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
            # print (url,macinfo,cokinfo,headersinfo)
            # headers = {"Authorization": "Bearer "+headersinfo}
            # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
            # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
            # rs = requests.get(get_genres, cookies=cookies, headers=headers)
            # sayfa = rs.json()['js']['total_items']
            # print ('sayfalama  :', sayfa)
            # for pagenext in range(1, int(sayfa+1)):
            for pagenext in range(1, 51):
                get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # print (rs.json()['js'])
                playlistgenre = rs.json()['js']['data']
                # print (playlistgenre)
                for listeler in playlistgenre:
                    # print (listeler)
                    name = listeler['name']
                    # print (name)
                    cmd = listeler['cmd']
                    # print (cmd)
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "stremxttskylive(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            # __settings__.openSettings()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                mac = macinfo
                headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                panelurl = url
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
                # try:
                r = requests.get(tokenurl, cookies=cookies, headers=headers)
                r.raise_for_status()
                jr = r.json()
                # print (jr)
                tokentext = jr['js']['token']
                # print(tokentext)
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                headers = {"Authorization": "Bearer "+tokentext}
                profile = panelurl + "/portal.php?type=stb&action=get_profile"
                rs = requests.get(profile, cookies=cookies, headers=headers)
                # print (rs.text)
                default_timezone = rs.json()['js']['default_timezone']
                # print (default_timezone)
                # print (rs.json()['js']['password'])
                cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
                # print (url,macinfo,cokinfo,headersinfo)
                # headers = {"Authorization": "Bearer "+headersinfo}
                # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
                # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
                # rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # sayfa = rs.json()['js']['total_items']
                # print ('sayfalama  :', sayfa)
                # for pagenext in range(1, int(sayfa+1)):
                for pagenext in range(1, 51):
                    get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    # print (rs.json()['js'])
                    playlistgenre = rs.json()['js']['data']
                    # print (playlistgenre)
                    for listeler in playlistgenre:
                        # print (listeler)
                        name = listeler['name']
                        # print (name)
                        cmd = listeler['cmd']
                        # print (cmd)
                        logo = listeler['logo']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "stremxttskylive(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
            else:
                # print ("denetim 5")
                sifrehatasi()
                return playList.clear(exit())
                # dialog.notification('Girilen Şifre Hatalı', 'Şifrenizi Kontrol ederek, tekrar deneyiniz!')
        
        
def stremxttskylive(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo):
    # print ('stremxttskylive  :',stremxttskylive)
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+str(headersinfo)}
    # cookies = {"mac":str(macinfo), "stb_lang":"en", "timezone":str(cokinfo)}
    get_genres = str(url) + "/portal.php?type=itv&action=create_link&cmd="+str(fix)+"&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.json()['js'])
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail})
    listitem.setInfo('video', {'name': name })
    playList.add(jrs,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
######################################
def xttskyvod(url,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    try:
        r = requests.get(tokenurl, cookies=cookies, headers=headers)
        r.raise_for_status()
        jr = r.json()
        # print (jr)
        tokentext = jr['js']['token']
        # print(tokentext)
        cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
        headers = {"Authorization": "Bearer "+tokentext}
        profile = panelurl + "/portal.php?type=stb&action=get_profile"
        rs = requests.get(profile, cookies=cookies, headers=headers)
        # print (rs.text)
        default_timezone = rs.json()['js']['default_timezone']
        # print (default_timezone)
        # print (rs.json()['js']['password'])
        cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
        # print (url,macinfo,cokinfo,headersinfo)
        # headers = {"Authorization": "Bearer "+headersinfo}
        # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
        # print (macinfo,cokinfo,headersinfo)
        get_genres = str(url) + "/portal.php?type=vod&action=get_categories&JsHttpRequest=1" + str(macinfo)
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        for listeler in rs.json()['js']:
            # print (listeler)
            if  not listeler['id'] != '*':
                pass
            else:
                if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                    if __settings__.getSetting("yetiskinackapat") == "true":
                        idler = listeler['id']
                        title= listeler['title']
                        # print ('selam 1 ',title)
                        thumbnaillive = images_path + "/xttmctv.png"
                        xttplaymac(FILENAME,title, "x18xttskyvodtopla(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
                    else:
                        pass
                else:
                    idler = listeler['id']
                    title= listeler['title']
                    # print ('selam 1 ',title)
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "xttskyvodtopla(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
    except:
        # print ('expvod2')
        return xttskyvod2(url,macinfo,cokinfo,headersinfo)
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskyvodtopla(url,fix,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (url,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
    # rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # sayfa = rs.json()['js']['total_items']
    # print ('sayfalama  :', sayfa)
    # for pagenext in range(1, int(sayfa+1)):
    for pagenext in range(1, 51):
        get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        playlistgenre = rs.json()['js']['data']
        # print (playlistgenre)
        for listeler in playlistgenre:
            # print (listeler)
            name = listeler['name']
            # print (name)
            cmd = listeler['cmd']
            # print (cmd)
            logo = listeler['screenshot_uri']
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            xttplaymac(FILENAME,name, "stremxttskyvod(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def x18xttskyvodtopla(url,fix,macinfo,cokinfo,headersinfo):
    # print ('gelen selam',url,fix,macinfo,cokinfo,headersinfo)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        # print ('gelen selam1')
        __settings__.openSettings()
        if datalog == "":
            print ('gelen selam2')
            return playList.clear(exit())
    else:
        # print ('gelen selam3')
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            mac = macinfo
            headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            panelurl = url
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
            # try:
            r = requests.get(tokenurl, cookies=cookies, headers=headers)
            r.raise_for_status()
            jr = r.json()
            # print (jr)
            tokentext = jr['js']['token']
            # print(tokentext)
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            headers = {"Authorization": "Bearer "+tokentext}
            profile = panelurl + "/portal.php?type=stb&action=get_profile"
            rs = requests.get(profile, cookies=cookies, headers=headers)
            # print (rs.text)
            default_timezone = rs.json()['js']['default_timezone']
            # print (default_timezone)
            # print (rs.json()['js']['password'])
            cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
            # print (url,macinfo,cokinfo,headersinfo)
            # headers = {"Authorization": "Bearer "+headersinfo}
            # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
            # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
            # rs = requests.get(get_genres, cookies=cookies, headers=headers)
            # sayfa = rs.json()['js']['total_items']
            # print ('sayfalama  :', sayfa)
            # for pagenext in range(1, int(sayfa+1)):
            for pagenext in range(1, 51):
                get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                print (rs.json()['js'])
                playlistgenre = rs.json()['js']['data']
                # print (playlistgenre)
                for listeler in playlistgenre:
                    # print (listeler)
                    name = listeler['name']
                    # print (name)
                    cmd = listeler['cmd']
                    # print (cmd)
                    logo = listeler['screenshot_uri']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "stremxttskyvod(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            # __settings__.openSettings()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                mac = macinfo
                headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                panelurl = url
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
                # try:
                r = requests.get(tokenurl, cookies=cookies, headers=headers)
                r.raise_for_status()
                jr = r.json()
                # print (jr)
                tokentext = jr['js']['token']
                # print(tokentext)
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                headers = {"Authorization": "Bearer "+tokentext}
                profile = panelurl + "/portal.php?type=stb&action=get_profile"
                rs = requests.get(profile, cookies=cookies, headers=headers)
                # print (rs.text)
                default_timezone = rs.json()['js']['default_timezone']
                # print (default_timezone)
                # print (rs.json()['js']['password'])
                cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
                # print (url,macinfo,cokinfo,headersinfo)
                # headers = {"Authorization": "Bearer "+headersinfo}
                # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
                # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
                # rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # sayfa = rs.json()['js']['total_items']
                # print ('sayfalama  :', sayfa)
                # for pagenext in range(1, int(sayfa+1)):
                for pagenext in range(1, 51):
                    get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    # print (rs.json()['js'])
                    playlistgenre = rs.json()['js']['data']
                    # print (playlistgenre)
                    for listeler in playlistgenre:
                        # print (listeler)
                        name = listeler['name']
                        # print (name)
                        cmd = listeler['cmd']
                        # print (cmd)
                        logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "stremxttskyvod(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
                
            else:
                # print ("denetim 5")
                sifrehatasi()
                return playList.clear(exit())
                # dialog.notification('Girilen Şifre Hatalı', 'Şifrenizi Kontrol ederek, tekrar deneyiniz!')
def stremxttskyvod(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo):
    # print ('stremxttskyvod  :',stremxttskyvod)
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    get_genres = str(url) + "/portal.php?type=vod&action=create_link&cmd="+fix+"&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.json()['js'])
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail})
    listitem.setInfo('video', {'name': name })
    playList.add(jrs,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
###########################################################################################################
def loglive2(url,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    get_genres = str(url) + "/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml" + str(macinfo)
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.text)
    # print (rs.json()['js'])
    for listeler in rs.json()['js']:
        # print (listeler)
        if  not listeler['id'] != '*':
            pass
        else:
            if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                if __settings__.getSetting("yetiskinackapat") == "true":
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "x18xttskylivetopla2(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
                else:
                    pass
            else:
                idler = listeler['id']
                title= listeler['title']
                thumbnaillive = images_path + "/xttmctv.png"
                xttplaymac(FILENAME,title, "xttskylivetopla2(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskylivetopla2(url,fix,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (url,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
    # rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # sayfa = rs.json()['js']['total_items']
    # print ('sayfalama  :', sayfa)
    # for pagenext in range(1, int(sayfa+1)):
    for pagenext in range(1, 51):
        get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        playlistgenre = rs.json()['js']['data']
        # print (playlistgenre)
        for listeler in playlistgenre:
            # print (listeler)
            name = listeler['name']
            # print (name)
            cmd = listeler['cmd']
            # print (cmd)
            logo = listeler['logo']
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            xttplaymac(FILENAME,name, "stremsxttskylive2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def x18xttskylivetopla2(url,fix,macinfo,cokinfo,headersinfo):
    # print ('gelen selam',url,fix,macinfo,cokinfo,headersinfo)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        # print ('gelen selam1')
        __settings__.openSettings()
        if datalog == "":
            # print ('gelen selam2')
            return playList.clear(exit())
    else:
        # print ('gelen selam3')
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            mac = macinfo
            headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            panelurl = url
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
            # try:
            r = requests.get(tokenurl, cookies=cookies, headers=headers)
            r.raise_for_status()
            jr = r.json()
            # print (jr)
            tokentext = jr['js']['token']
            # print(tokentext)
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            headers = {"Authorization": "Bearer "+tokentext}
            profile = panelurl + "/portal.php?type=stb&action=get_profile"
            rs = requests.get(profile, cookies=cookies, headers=headers)
            # print (rs.text)
            default_timezone = rs.json()['js']['default_timezone']
            # print (default_timezone)
            # print (rs.json()['js']['password'])
            cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
            # print (url,macinfo,cokinfo,headersinfo)
            # headers = {"Authorization": "Bearer "+headersinfo}
            # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
            # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
            # rs = requests.get(get_genres, cookies=cookies, headers=headers)
            # sayfa = rs.json()['js']['total_items']
            # print ('sayfalama  :', sayfa)
            # for pagenext in range(1, int(sayfa+1)):
            for pagenext in range(1, 51):
                get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # print (rs.json()['js'])
                playlistgenre = rs.json()['js']['data']
                # print (playlistgenre)
                for listeler in playlistgenre:
                    # print (listeler)
                    name = listeler['name']
                    # print (name)
                    cmd = listeler['cmd']
                    # print (cmd)
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "stremsxttskylive2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            # __settings__.openSettings()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                mac = macinfo
                headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                panelurl = url
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
                # try:
                r = requests.get(tokenurl, cookies=cookies, headers=headers)
                r.raise_for_status()
                jr = r.json()
                # print (jr)
                tokentext = jr['js']['token']
                # print(tokentext)
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                headers = {"Authorization": "Bearer "+tokentext}
                profile = panelurl + "/portal.php?type=stb&action=get_profile"
                rs = requests.get(profile, cookies=cookies, headers=headers)
                # print (rs.text)
                default_timezone = rs.json()['js']['default_timezone']
                # print (default_timezone)
                # print (rs.json()['js']['password'])
                cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
                # print (url,macinfo,cokinfo,headersinfo)
                # headers = {"Authorization": "Bearer "+headersinfo}
                # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
                # get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p=500&JsHttpRequest=1-xml&from_ch_id=0"
                # rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # sayfa = rs.json()['js']['total_items']
                # print ('sayfalama  :', sayfa)
                # for pagenext in range(1, int(sayfa+1)):
                for pagenext in range(1, 51):
                    get_genres = str(url) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    # print (rs.json()['js'])
                    playlistgenre = rs.json()['js']['data']
                    # print (playlistgenre)
                    for listeler in playlistgenre:
                        # print (listeler)
                        name = listeler['name']
                        # print (name)
                        cmd = listeler['cmd']
                        # print (cmd)
                        logo = listeler['logo']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "stremsxttskylive2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
            else:
                # print ("denetim 5")
                sifrehatasi()
                return playList.clear(exit())
                # dialog.notification('Girilen Şifre Hatalı', 'Şifrenizi Kontrol ederek, tekrar deneyiniz!')
def stremsxttskylive2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo):
    # print ('stremsxttskylive2  :',stremsxttskylive2)
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+str(headersinfo)}
    # cookies = {"mac":str(macinfo), "stb_lang":"en", "timezone":str(cokinfo)}
    get_genres = str(url) + "/portal.php?type=itv&action=create_link&cmd="+str(fix)+"&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.json()['js'])
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail})
    listitem.setInfo('video', {'name': name })
    playList.add(jrs,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
######################################
def xttskyvod2(url,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (url,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    # print (macinfo,cokinfo,headersinfo)
    get_genres = str(url) + "/portal.php?type=vod&action=get_categories&JsHttpRequest=1" + str(macinfo)
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.json()['js'])
    for listeler in rs.json()['js']:
        # print (listeler)
        if  not listeler['id'] != '*':
        
        
            pass
        else:
            if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                if __settings__.getSetting("yetiskinackapat") == "true":
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "x18xttskyvodtopla2(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
                else:
                    return playList.clear(exit())
            else:
                idler = listeler['id']
                title= listeler['title']
                thumbnaillive = images_path + "/xttmctv.png"
                xttplaymac(FILENAME,title, "xttskyvodtopla2(url,fix,macinfo,cokinfo,headersinfo)",url,thumbnaillive,"",str(idler),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def x18xttskyvodtopla2(url,fix,macinfo,cokinfo,headersinfo):
    # print ('gelen selam',url,fix,macinfo,cokinfo,headersinfo)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        # print ('gelen selam1')
        __settings__.openSettings()
        if datalog == "":
            # print ('gelen selam2')
            return playList.clear(exit())
    else:
        # print ('gelen selam3')
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            mac = macinfo
            headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
            panelurl = url
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
            # try:
            r = requests.get(tokenurl, cookies=cookies, headers=headers)
            r.raise_for_status()
            jr = r.json()
            # print (jr)
            tokentext = jr['js']['token']
            # print(tokentext)
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            headers = {"Authorization": "Bearer "+tokentext}
            profile = panelurl + "/portal.php?type=stb&action=get_profile"
            rs = requests.get(profile, cookies=cookies, headers=headers)
            # print (rs.text)
            default_timezone = rs.json()['js']['default_timezone']
            # print (default_timezone)
            # print (rs.json()['js']['password'])
            cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
            # print (url,macinfo,cokinfo,headersinfo)
            # headers = {"Authorization": "Bearer "+headersinfo}
            # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
            # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
            # rs = requests.get(get_genres, cookies=cookies, headers=headers)
            # sayfa = rs.json()['js']['total_items']
            # print ('sayfalama  :', sayfa)
            # for pagenext in range(1, int(sayfa+1)):
            for pagenext in range(1, 51):
                get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # print (rs.json()['js'])
                playlistgenre = rs.json()['js']['data']
                # print (playlistgenre)
                for listeler in playlistgenre:
                    # print (listeler)
                    name = listeler['name']
                    # print (name)
                    cmd = listeler['cmd']
                    # print (cmd)
                    logo = listeler['screenshot_uri']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "stremsxttskyvod2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            # __settings__.openSettings()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                mac = macinfo
                headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
                panelurl = url
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
                # try:
                r = requests.get(tokenurl, cookies=cookies, headers=headers)
                r.raise_for_status()
                jr = r.json()
                # print (jr)
                tokentext = jr['js']['token']
                # print(tokentext)
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                headers = {"Authorization": "Bearer "+tokentext}
                profile = panelurl + "/portal.php?type=stb&action=get_profile"
                rs = requests.get(profile, cookies=cookies, headers=headers)
                # print (rs.text)
                default_timezone = rs.json()['js']['default_timezone']
                # print (default_timezone)
                # print (rs.json()['js']['password'])
                cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
                # print (url,macinfo,cokinfo,headersinfo)
                # headers = {"Authorization": "Bearer "+headersinfo}
                # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
                # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
                # rs = requests.get(get_genres, cookies=cookies, headers=headers)
                # sayfa = rs.json()['js']['total_items']
                # print ('sayfalama  :', sayfa)
                # for pagenext in range(1, int(sayfa+1)):
                for pagenext in range(1, 51):
                    get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    # print (rs.json()['js'])
                    playlistgenre = rs.json()['js']['data']
                    # print (playlistgenre)
                    for listeler in playlistgenre:
                        # print (listeler)
                        name = listeler['name']
                        # print (name)
                        cmd = listeler['cmd']
                        # print (cmd)
                        logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "stremsxttskyvod2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
            else:
                # print ("denetim 5")
                sifrehatasi()
                return playList.clear(exit())
                # dialog.notification('Girilen Şifre Hatalı', 'Şifrenizi Kontrol ederek, tekrar deneyiniz!')
def xttskyvodtopla2(url,fix,macinfo,cokinfo,headersinfo):
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (url,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    # get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p=500&JsHttpRequest=1-xml"
    # rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # sayfa = rs.json()['js']['total_items']
    # print ('sayfalama  :', sayfa)
    # for pagenext in range(1, int(sayfa+1)):
    for pagenext in range(1, 51):
        get_genres = str(url) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        # print (rs.json()['js'])
        playlistgenre = rs.json()['js']['data']
        # print (playlistgenre)
        for listeler in playlistgenre:
            # print (listeler)
            name = listeler['name']
            # print (name)
            cmd = listeler['cmd']
            # print (cmd)
            logo = listeler['screenshot_uri']
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            xttplaymac(FILENAME,name, "stremsxttskyvod2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)",url,logo,"",str(cmd),str(macinfo),str(cokinfo),str(headersinfo))
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def stremsxttskyvod2(name,url,thumbnail,fix,macinfo,cokinfo,headersinfo):
    # print ('stremsxttskyvod2  :',stremsxttskyvod2)
    mac = macinfo
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    # User-Agent = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    panelurl = url
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = panelurl + "/portal.php?action=handshake&type=stb&token=&mac=" + mac
    # try:
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    # print (jr)
    tokentext = jr['js']['token']
    # print(tokentext)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = panelurl + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    # print (rs.text)
    default_timezone = rs.json()['js']['default_timezone']
    # print (default_timezone)
    # print (rs.json()['js']['password'])
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    # print (name,url,thumbnail,fix,macinfo,cokinfo,headersinfo)
    # headers = {"Authorization": "Bearer "+headersinfo}
    # cookies = {"mac":macinfo, "stb_lang":"en", "timezone":cokinfo}
    get_genres = str(url) + "/portal.php?type=vod&action=create_link&cmd="+fix+"&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    # print (rs.json()['js'])
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail})
    listitem.setInfo('video', {'name': name })
    playList.add(jrs,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
def replace_ascii(k):
        y= ''+';&#'.join(str(ord(c)) for c in k)
        codeasci='&#'+y+';'
        return codeasci
def encodee(url):
        asciicode=replace_ascii(url)
        basecode=base64.b64encode(asciicode.encode('ascii'))
        # print (str(basecode).replace("b'", '').replace("'", '').replace(" ", ''))
        return str(basecode).replace("b'", '').replace("'", '').replace(" ", '')
def decodee(url):
        decod_et = str(url).replace("b'", '').replace("'", '')
        # print (html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", '')))
        return html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", ''))
######################################
def replace(x):
    x = x.replace('January', '01').replace('February', '02').replace('March', '03').replace('April', '04').replace('May', '05').replace('June', '06').replace('July', '07').replace('August', '08').replace('September', '09').replace('October', '10').replace('November', '11').replace('December', '12')
    return x
def replaceaylarturk(x):
    x = x.replace('January', 'Ocak').replace('February', 'Şubat').replace('March', 'Mart').replace('April', 'Nisan').replace('May', 'Mayıs').replace('June', 'Haziran').replace('July', 'Temmuz').replace('August', 'Ağustos').replace('September', 'Eylül').replace('October', 'Ekim').replace('November', 'Kasım').replace('December', 'Aralık')
    return x
def replacetarih(x):
    x = x.replace(' ','').replace(",",'')
    # print (x)
    return x
def xttplaymac(FILENAME,name,method,url,thumbnail,thumbfolder,fix,macinfo,cokinfo,headersinfo):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&fileName="+urllib.parse.quote_plus(FILENAME)+"&fix="+urllib.parse.quote_plus(fix)+"&macinfo="+urllib.parse.quote_plus(macinfo)+"&cokinfo="+urllib.parse.quote_plus(cokinfo)+"&headersinfo="+urllib.parse.quote_plus(headersinfo)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail})
    liz.setInfo(type="Video", infoLabels={"Title": name })
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    if method != "":
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # return ok
    else:
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
def login():
    return True
    # try:
        # insidexttmc()
        # xttmc=htmlp.unescape(base64.b64decode(stone))
        # datalogin = {
               # 'username': username,
               # 'password': password,
               # 'action':'do_login',
               # }
        # getlog=net.http_POST(xttmc, datalogin).content.encode('utf-8', 'ignore')
        # if '>'+username+'<' in getlog:
            # return True
        # else:
            # hataxttmc()
            # return playList.clear(exit())
    # except:
        # try:
            # userpass=re.search('\#>xtt<\#(.*?)\#>xtt<\#', str(getlog)).group(1)
            # if userpass in getlog:
                # return True
            # else:
                # pass
        # except:
            # hataxttmc()
            # return playList.clear(exit())
def insidexttmc():
    if password == "":
        __settings__.openSettings()
        if password == "":
            return playList.clear(exit())
    else:
        return
def hataxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC BAGLANTI HATASI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC[/B][/COLOR]','  [COLOR yellow][B]Bilgilerinizi dogru girdiginizden emin olun ve tekrar giris yapmayi deneyin.[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]XTT Player Aktif[/B][/COLOR]")

################################################################################cp
def datacp():
    # return True
    insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = decodee(str(r.text))
    # print (rs)
    # print (str(json.loads(rs)['paneurl']))
    # js = str(json.loads(rs)['paneurl'][0]['datalog'])
    js = str(str(json.loads(rs)['keydata'])).strip('[]')
    match=re.compile('(?:\"|\')keylog(?:\"|\')\:\s*(?:\"|\')\>xttsky\<'+keylog+'\>xttsky\<(?:\"|\')').findall(str(js))
    if not match != []:
        hatacpxttmc()
        return playList.clear(exit())
    else: return True
    # try:
        # insidecpxttmc()
        # xttmc=htmlp.unescape(base64.b64decode(stone))
        # datalogin = {
               # 'username': username,
               # 'password': password,
               # 'action':'do_login',
               # }
        # getlog=net.http_POST(xttmc, datalogin).content.encode('utf-8', 'ignore')
        # if '>'+username+'<' in getlog:
            # cpwelcom = re.search('\#>xttmc<\#(.*?)\#>xttmc<\#', str(getlog)).group(1)
            # if cpwelcom in getlog:
                # return True
            # else:
                # hatauser()
                # return playList.clear(exit())
        # else:
            # return playList.clear(exit())
    # except:
        # try:
            # userpasscp=re.search('>xtt<(.*?)>xtt<', str(getlog)).group(1)
            # if userpasscp in getlog:
                # return True
            # else:
                # hatauser()
                # return playList.clear(exit())
        # except:
            # hatauser()
            # return playList.clear(exit())
def insidecpxttmc():
    datalog = __settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        return
def hatacpxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTSKY KULLANICI UYELIK SORUNU..![/B][/COLOR]', '  [COLOR blue][B]LUTFEN GIRIS BILGILERINIZI KONTROL EDIN[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]Sorun mu Yasadiniz?[/COLOR][/B]","[COLOR gray][B]XTTSKY[/B][/COLOR]")
def hatauser():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC UYARI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC YÖNETİM[/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
def sifrehatasi():
    xbmcgui.Dialog().ok('[COLOR red][B]GİRİLEN ŞİFRE HATALI..![/B][/COLOR]', '  [COLOR blue][B]LÜTFEN ŞİFRENİZİ KONTROL EDEREK TEKRAR DENEYİNİZ..![/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
################################################################################
def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
######################################
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
params = get_params()
name = None
fileName = None
method = None
url = None
thumbnail = None
thumbfolder = None
fix = None
macinfo = None
cokinfo = None
headersinfo = None
try:
    name = urllib.parse.unquote_plus(params["name"])
except: pass
try:
    fileName = urllib.parse.unquote_plus(params["fileName"])
except: pass
try:
    method = urllib.parse.unquote_plus(params["method"])
except: pass
try:
    url = urllib.parse.unquote_plus(params["url"])
except: pass
try:
    thumbnail = urllib.parse.unquote_plus(params["thumbnail"])
except: pass
try:
    thumbfolder = urllib.parse.unquote_plus(params["thumbfolder"])
except: pass
try:
    fix = urllib.parse.unquote_plus(params["fix"])
except: pass
try:
    macinfo = urllib.parse.unquote_plus(params["macinfo"])
except: pass
try:
    cokinfo = urllib.parse.unquote_plus(params["cokinfo"])
except: pass
try:
    headersinfo = urllib.parse.unquote_plus(params["headersinfo"])
except: pass
if fileName == None:
    main()
    # listing(IMAGES_PATH,xtttest)
else:
    exec ("import "+fileName+" as channel")
    exec ("channel."+str(method))
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)