# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import html
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import base64
import requests
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
# library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
# sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
# channels = xbmc.translatePath(os.path.join(home, 'channels'))
# sys.path.append(channels)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
logdata = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA4OyYjMTExOyYjMTAzOyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()

def skyxttplayer(name,url,thumbnail):
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', {'name': name })
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
##################################betikler############################################
def xttplaymac(FILENAME,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&fileName="+urllib.parse.quote_plus(FILENAME)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"Title": name })
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    if method != "":
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # return ok
    else:
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
##################################betikler############################################
def replace_ascii(k):
        y= ''+';&#'.join(str(ord(c)) for c in k)
        codeasci='&#'+y+';'
        return codeasci
def encodee(url):
        asciicode=replace_ascii(url)
        basecode=base64.b64encode(asciicode.encode('ascii'))
        # print (str(basecode).replace("b'", '').replace("'", '').replace(" ", ''))
        return str(basecode).replace("b'", '').replace("'", '').replace(" ", '')
def decodee(url):
        decod_et = str(url).replace("b'", '').replace("'", '')
        # print (html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", '')))
        return html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", ''))
######################################
def login():
    return True
def insidexttmc():
    if password == "":
        __settings__.openSettings()
        if password == "":
            return playList.clear(exit())
    else:
        return
def hataxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC BAGLANTI HATASI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC[/B][/COLOR]','  [COLOR yellow][B]Bilgilerinizi dogru girdiginizden emin olun ve tekrar giris yapmayi deneyin.[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]XTT Player Aktif[/B][/COLOR]")

################################################################################cp
def datacp():
    # return True
    insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = decodee(str(r.text))
    # print (rs)
    # print (str(json.loads(rs)['paneurl']))
    # js = str(json.loads(rs)['paneurl'][0]['datalog'])
    js = str(str(json.loads(rs)['keydata'])).strip('[]')
    match=re.compile('(?:\"|\')keylog(?:\"|\')\:\s*(?:\"|\')\>xttsky\<'+keylog+'\>xttsky\<(?:\"|\')').findall(str(js))
    if not match != []:
        hatacpxttmc()
        return playList.clear(exit())
    else: return True
def insidecpxttmc():
    datalog = __settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        return
def hatacpxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTSKY KULLANICI UYELIK SORUNU..![/B][/COLOR]', '  [COLOR blue][B]LUTFEN GIRIS BILGILERINIZI KONTROL EDIN[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]Sorun mu Yasadiniz?[/COLOR][/B]","[COLOR gray][B]XTTSKY[/B][/COLOR]")
def hatauser():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC UYARI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC YÖNETİM[/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
def sifrehatasi():
    xbmcgui.Dialog().ok('[COLOR red][B]GİRİLEN ŞİFRE HATALI..![/B][/COLOR]', '  [COLOR blue][B]LÜTFEN ŞİFRENİZİ KONTROL EDEREK TEKRAR DENEYİNİZ..![/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
################################################################################
def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
##################### py ot okuyucu #######################
def loadImports(yol):
    files = os.listdir(yol)
    global imps
    imps = []
    for i in range(len(files)):
        py_name = files[i].split('.')
        if len(py_name) > 1:
            if py_name[1] == 'py' and py_name[0] != '__init__':
               py_name = py_name[0]
               imps.append(py_name)
    file = open(yol+'/__init__.py','w')
    toWrite = '__all__ = '+str(imps)
    file.write(toWrite)
    file.close()
    return imps
def listChannels(images_path):
    for FILENAME in imps:
        thumbnail= os.path.join(images_path, FILENAME+".png")
        if not thumbnail != "":
            thumbnail=thumbnail
        else:
            thumbnail=images_path+'/xttsmarttv.png'
        xttplaymac(FILENAME,FILENAME, "main()","",thumbnail,"","","","","")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
def listing(images_path,url):
    loadImports(url)
    listChannels(images_path)
    

##################### okuyucu #######################

# maininfohtmlxml = 'infoxml()' # XML
xttmcturkfilmxml = 'mainxml()' # XML
xttmckliphtmlxml = 'mainxml()' # XML
mainxttmctvxml = 'mainxml()' # XML
mainxtttvxml = 'xtttv.mainxml()' # XML
# '''#############################'''
maininfohtmlxml = 'infohtml()' # HTML
# xttmcturkfilmxml = 'mainhtml()' # HTML
# xttmckliphtmlxml = 'mainhtml()' # HTML
# mainxttmctvxml = 'mainhtml()' # HTML
# mainxtttvxml = 'xtttv.mainhtml()' # HTML
# aHR0cHM6Ly90d2l0dGVyLmNvbS9JemxlQWR1bHQ
    