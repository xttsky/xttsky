# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import math
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import xttskytools
import skym3uplayer
import skyinfo
import skyxttseries
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
# channels = xbmc.translatePath(os.path.join(home, 'channels'))
# sys.path.append(channels)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon = __settings__.getAddonInfo('icon')
filename = "skysmart"
logdata = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA4OyYjMTExOyYjMTAzOyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
dataurl = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA5OyYjOTc7JiM5OTsmIzQ2OyYjMTIwOyYjMTA5OyYjMTA4Ow=="
dataxml = "JiM2OTsmIzU4OyYjNDc7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMDk7JiM5OTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTA5OyYjOTk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
maininfohtmlxmltest = xttskytools.maininfohtmlxml
def main():
    # datacp()
    xttskytools.insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(xttskytools.decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(xttskytools.decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(xttskytools.decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = xttskytools.decodee(r.text)
    rs = json.loads(rs)['keydata']
    for ld in rs:
        match=re.compile('\>xttsky\<'+keylog+'\>xttsky\<').findall(str(ld['keylog']))
        if not match != []:
            xttskytools.hatacpxttmc()
            return playList.clear(exit())
        else: 
            return mainnet()
def mainnet():
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    if __settings__.getSetting("PanelAcKapat") == "false":
        pass
    else:
        r = requests.get(xttskytools.decodee(dataurl), headers=headers)
        r.raise_for_status()
        # print (r.text)
        if '.' in r.text:
            jr = r.json()['data']
            for panelsayisi in range(len(jr)):
                panel = jr[panelsayisi]
                group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(filename,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,mac)",str(panel['panelhost']),thumbnail,"","",str(panel['panelmac']),"","","")
        else:
            rs = xttskytools.decodee(r.text)
            js = json.loads(rs)['data']
            for pm in range(len(js)):
                group_title = 'SMART  ' + "[B][COLOR red]"+str(pm+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(filename,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,mac)",str(js[pm]['panelhost']),thumbnail,"","",str(js[pm]['panelmac']),"","","")
    ################## panelozellist ######################
    if __settings__.getSetting("PanelListeAcKapat") == "false":
        pass
    else:
        if __settings__.getSetting("panel1onoff") == "true":
            host1 = __settings__.getSetting("host1")
            mac1 = __settings__.getSetting("mac1")
        else:
            host1 = ""
            mac1 = ""
        if __settings__.getSetting("panel2onoff") == "true":
            host2 = __settings__.getSetting("host2")
            mac2 = __settings__.getSetting("mac2")
        else:
            host2 = ""
            mac2 = ""
        if __settings__.getSetting("panel3onoff") == "true":
            host3 = __settings__.getSetting("host3")
            mac3 = __settings__.getSetting("mac3")
        else:
            host3 = ""
            mac3 = ""
        if __settings__.getSetting("panel4onoff") == "true":
            host4 = __settings__.getSetting("host4")
            mac4 = __settings__.getSetting("mac4")
        else:
            host4 = ""
            mac4 = ""
        if __settings__.getSetting("panel5onoff") == "true":
            host5 = __settings__.getSetting("host5")
            mac5 = __settings__.getSetting("mac5")
        else:
            host5 = ""
            mac5 = ""
        if __settings__.getSetting("panel6onoff") == "true":
            host6 = __settings__.getSetting("host6")
            mac6 = __settings__.getSetting("mac6")
        else:
            host6 = ""
            mac6 = ""
        if __settings__.getSetting("panel7onoff") == "true":
            host7 = __settings__.getSetting("host7")
            mac7 = __settings__.getSetting("mac7")
        else:
            host7 = ""
            mac7 = ""
        if __settings__.getSetting("panel8onoff") == "true":
            host8 = __settings__.getSetting("host8")
            mac8 = __settings__.getSetting("mac8")
        else:
            host8 = ""
            mac8 = ""
        if __settings__.getSetting("panel9onoff") == "true":
            host9 = __settings__.getSetting("host9")
            mac9 = __settings__.getSetting("mac9")
        else:
            host9 = ""
            mac9 = ""
        if __settings__.getSetting("panel10onoff") == "true":
            host10 = __settings__.getSetting("host10")
            mac10 = __settings__.getSetting("mac10")
        else:
            host10 = ""
            mac10 = ""
        if __settings__.getSetting("panel11onoff") == "true":
            host11 = __settings__.getSetting("host11")
            mac11 = __settings__.getSetting("mac11")
        else:
            host11 = ""
            mac11 = ""
        if __settings__.getSetting("panel12onoff") == "true":
            host12 = __settings__.getSetting("host12")
            mac12 = __settings__.getSetting("mac12")
        else:
            host12 = ""
            mac12 = ""
        if __settings__.getSetting("panel13onoff") == "true":
            host13 = __settings__.getSetting("host13")
            mac13 = __settings__.getSetting("mac13")
        else:
            host13 = ""
            mac13 = ""
        if __settings__.getSetting("panel14onoff") == "true":
            host14 = __settings__.getSetting("host14")
            mac14 = __settings__.getSetting("mac14")
        else:
            host14 = ""
            mac14 = ""
        if __settings__.getSetting("panel15onoff") == "true":
            host15 = __settings__.getSetting("host15")
            mac15 = __settings__.getSetting("mac15")
        else:
            host15 = ""
            mac15 = ""
        settingspanel = []
        data = [
        {"datalog": host1, "datamac": mac1},
        {"datalog": host2, "datamac": mac2},
        {"datalog": host3, "datamac": mac3},
        {"datalog": host4, "datamac": mac4},
        {"datalog": host5, "datamac": mac5},
        {"datalog": host6, "datamac": mac6},
        {"datalog": host7, "datamac": mac7},
        {"datalog": host8, "datamac": mac8},
        {"datalog": host9, "datamac": mac9},
        {"datalog": host10, "datamac": mac10},
        {"datalog": host11, "datamac": mac11},
        {"datalog": host12, "datamac": mac12},
        {"datalog": host13, "datamac": mac13},
        {"datalog": host14, "datamac": mac14},
        {"datalog": host15, "datamac": mac15}
        ]
        for panelsayisi in range(len(data)):
            panel = data[panelsayisi]['datalog']
            if not data[panelsayisi]['datalog'] != "":
                pass
            else:
                settingspanel.append((data[panelsayisi]))
        if settingspanel == []:
            pass
        else:
            for panelok in range(len(settingspanel)):
                group_title = 'SMART PANEL LİSTE  ' + "[B][COLOR red]"+str(panelok+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(filename,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,mac)",str(settingspanel[panelok]['datalog']),thumbnail,"","",str(settingspanel[panelok]['datamac']),"","","")
    ################## m3ulist ####################
    if __settings__.getSetting("M3uListeAcKapat") == "false":
        pass
    else:
        skym3uplayer.m3umain()
    if __settings__.getSetting("bilgipaneli") == "false":
        pass
    else:
        xttplaymac(filename,"[B][COLOR lightblue] Info..[COLOR yellow]![/COLOR] [/COLOR][/B]", "skyinfo.infomain()","","","xttmcinfo","","","","","")
        
    xbmc.executebuiltin("Container.SetViewMode(500)")
def panelmac(url,mac):
    mac = str(mac)
    panelurl = str(url)
    timezone = 'America/Chicago';
    thumbnaillive = images_path + "/xttsmarttv.png"
    thumbnailvod = images_path + "/xttsine.png"
    xttplaymac(filename,str("LIVE"), "xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnaillive,"","",str(mac),str(timezone),"","itv&action")
    xttplaymac(filename,str("VOD"), "xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailvod,"","",str(mac),str(timezone),"","vod&action")
    xttplaymac(filename,str("SERİES"), "skyxttseries.xttskyseries(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailvod,"","",str(mac),str(timezone),"","series&action")
    xttplaymac(filename,str("LİVE LİSTE"), "getAllChannels(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailvod,"","",str(mac),str(timezone),"","itv&action")
    xbmc.executebuiltin("Container.SetViewMode(500)")
########################  XTTSKY  ###########################
def xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    try:
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        if not playinfo !="itv&action":
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_genres',
                'JsHttpRequest' : '1-xml',
                'mac' : mac})
            playinfo = "itv&action"
        else:
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'vod', 
                'action' : 'get_categories',
                'JsHttpRequest' : '1-xml',
                'mac' : mac})
            playinfo = "vod&action"
        results = info['js']
        for listeler in results:
            if  not listeler['id'] != '*':
                pass
            else:
                if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                    if __settings__.getSetting("yetiskinackapat") == "true":
                        idler = listeler['id']
                        title= listeler['title']
                        thumbnaillive = images_path + "/xttmctv.png"
                        xttplaymac(filename,title, "xttsky18topla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",url,thumbnaillive,"",str(idler),str(mac),str(timezone),"",str(playinfo))
                    else:
                        pass
                else:
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(filename,title, "xttskytoplaepg(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",url,thumbnaillive,"",str(idler),str(mac),str(timezone),"",str(playinfo))
        xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
        xbmc.executebuiltin("Container.SetViewMode(500)")
    except:
        return playList.clear(exit())
def xttskytoplaepg(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    if playinfo !="itv&action":
        return xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
    else:
        try:
            epgget = xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
        except:
            pass
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        for page in range(1, 500):
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_ordered_list',
                'genre' : fix,
                'p' : page,
                'fav' : '0',
                'JsHttpRequest' : '1-xml'})
            results = info['js']['data']
            if not results !=[]:
                break
            else:
                for listeler in results:
                    name = listeler["name"]
                    ch_id = listeler['id']
                    cmd = "http://localhost/ch/"+ch_id+"_"
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    epghits = []
                    try:
                        epgtime = epgget[ch_id]
                        for epggelen in epgtime:
                            try:
                                if not epggelen['t_time'] !="":
                                    pass
                                else:
                                    tarih = "[B][COLOR yellow]"+epggelen['on_date']+"[/COLOR][/B]"
                                    epghits.append((tarih))
                            except: pass
                            try:
                                if not epggelen['name'] !="":
                                    pass
                                else:
                                    program = "[B][COLOR blue]Program : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['name']+"[/COLOR][/B]"
                                    epghits.append((program))
                            except: pass
                            try:
                                if not epggelen['t_time'] !="":
                                    pass
                                else:
                                    zaman = "[B][COLOR blue]Başlangıç : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time']+"[/COLOR][/B] - [B][COLOR blue]Bitiş : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time_to']+"[/COLOR][/B]"
                                    epghits.append((zaman))
                            except: pass
                            try:
                                if not epggelen['descr'] !="" or not epggelen['descr'] !="\n" or not epggelen['descr'] !=" ":
                                    pass
                                else:
                                    konu = "[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['descr']+"[/COLOR][/B]"
                                    epghits.append((konu))
                            except: pass
                            # print (epggelen['on_date']+" - "+epggelen['t_time']+" - "+epggelen['t_time_to']+"\n"+epggelen['name']+"\n"+epggelen['descr']+"\n")
                    except: pass
                    if not epghits != []:
                        labels = "[B][COLOR blue]"+name+"[/COLOR][/B]"
                    else:
                        labels = replace_fix(str(epghits))
                    xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
def xttskytopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    if playinfo !="itv&action":
        return xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
    else:
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        for page in range(1, 500):
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_ordered_list',
                'genre' : fix,
                'p' : page,
                'fav' : '0',
                'JsHttpRequest' : '1-xml'})
            results = info['js']['data']
            if not results !=[]:
                break
            else:
                for listeler in results:
                    name = listeler["name"]
                    ch_id = listeler['id']
                    cmd = "http://localhost/ch/"+ch_id+"_"
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    labels = name
                    xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
def xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    for page in range(1, 500):
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod', 
            'action' : 'get_ordered_list',
            'category' : fix,
            'p' : page,
            'fav' : '0',
            'JsHttpRequest' : '1-xml'})
        results = info['js']['data']
        if not results !=[]:
            break
        else:
            for listeler in results:
                name = listeler["name"]
                cmd = listeler['cmd']
                logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                labelsgroup = []
                try:
                    if not listeler['genres_str'] !="N/A":
                        pass
                    else:
                        tur = '[B][COLOR blue]Tür : [/COLOR][/B][B][COLOR darkgray]'+listeler['genres_str']+'[/COLOR][/B]'
                        labelsgroup.append((tur))
                except: pass
                try:
                    if not listeler['director'] !="N/A":
                        pass
                    else:
                        director = '[B][COLOR blue]Yönetmen : [/COLOR][/B][B][COLOR darkgray]'+listeler['director']+'[/COLOR][/B]'
                        labelsgroup.append((director))
                except: pass
                try:
                    if not listeler['actors'] !="N/A":
                        pass
                    else:
                        actors = '[B][COLOR blue]Oyuncular : [/COLOR][/B][B][COLOR darkgray]'+listeler['actors']+'[/COLOR][/B]'
                        labelsgroup.append((actors))
                except: pass
                try:
                    if not listeler['year'] !="N/A":
                        pass
                    else:
                        year = '[B][COLOR blue]Yapım Yılı : [/COLOR][/B][B][COLOR darkgray]'+listeler['year']+'[/COLOR][/B]'
                        labelsgroup.append((year))
                except: pass
                puantime = []
                try:
                    try:
                        if not listeler['time'] !="N/A" or not listeler['time'] !=0:
                            pass
                        else:
                            time = '[B][COLOR blue]Süre : [/COLOR][/B][B][COLOR darkgray]'+str(listeler['time'])+'[/COLOR][/B]'
                            # print (str(time))
                            puantime.append((str(time)))
                    except: pass
                    try:
                        if not listeler['rating_imdb'] !="N/A":
                            pass
                        else:
                            rating = '[B][COLOR blue]IMBD : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_imdb']+'[/COLOR][/B]'
                            puantime.append((rating))
                    except: pass
                except: pass
                if not puantime !=[]:
                    pass
                else:
                    timeimbd = str(puantime).replace('", "', "  ").replace('\', "', "  ").replace('", \'', "  ").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace("', '", "    ").replace('", "', "    ").replace('\', "', "    ").replace('", \'', "    ")
                    # print (timeimbd)
                    labelsgroup.append((timeimbd))
                # try:
                    # MPAA = '[B][COLOR blue]MPAA : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_kinopoisk']+'[/COLOR][/B]'
                    # labelsgroup.append((MPAA))
                # except: pass
                
                # try:
                    # if not listeler['age'] !="N/A":
                        # pass
                    # else:
                        # age = '[B][COLOR blue]Yaş Sınırı : [/COLOR][/B][B][COLOR darkgray]'+listeler['age']+'[/COLOR][/B]'
                        # labelsgroup.append((age))
                # except: pass
                try:
                    if not listeler['description'] !="N/A":
                        pass
                    else:
                        plot = '[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR yellow]'+listeler['description']+'[/COLOR][/B]'
                        labelsgroup.append((plot))
                except: pass
                if not labelsgroup !=[]:
                    labels = "[B][COLOR blue]"+name+"[/COLOR][/B]"
                else:
                    labels = replace_fix(str(labelsgroup))
                xttplaymeta(filename,str(name), "testplayermeta(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    xbmc.executebuiltin("Container.SetViewMode(54)")
def xttsky18topla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    fix = str(fix)
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            for page in range(1, 500):
                if not playinfo !="itv&action":
                    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                        'type' : 'itv', 
                        'action' : 'get_ordered_list',
                        'genre' : fix,
                        'p' : page,
                        'fav' : '0',
                        'JsHttpRequest' : '1-xml'})
                else:
                    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                        'type' : 'vod', 
                        'action' : 'get_ordered_list',
                        'category' : fix,
                        'p' : page,
                        'fav' : '0',
                        'JsHttpRequest' : '1-xml'})
                results = info['js']['data']
                if not results !=[]:
                    break
                else:
                    for listeler in results:
                        # id = i["id"]
                        # number = i["number"]
                        name = listeler["name"]
                        if not playinfo !="itv&action":
                            ch_id = listeler['id']
                            cmd = "http://localhost/ch/"+ch_id+"_"
                            logo = listeler['logo']
                        else:
                            cmd = listeler['cmd']
                            logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
                    xbmc.executebuiltin("Container.SetViewMode(500)")
            xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                for page in range(1, 500):
                    if not playinfo !="itv&action":
                        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                            'type' : 'itv', 
                            'action' : 'get_ordered_list',
                            'genre' : fix,
                            'p' : page,
                            'fav' : '0',
                            'JsHttpRequest' : '1-xml'})
                    else:
                        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                            'type' : 'vod', 
                            'action' : 'get_ordered_list',
                            'category' : fix,
                            'p' : page,
                            'fav' : '0',
                            'JsHttpRequest' : '1-xml'})
                    results = info['js']['data']
                    if not results !=[]:
                        break
                    else:
                        for listeler in results:
                            name = listeler["name"]
                            if not playinfo !="itv&action":
                                ch_id = listeler['id']
                                cmd = "http://localhost/ch/"+ch_id+"_"
                                logo = listeler['logo']
                            else:
                                cmd = listeler['cmd']
                                logo = listeler['screenshot_uri']
                            if not logo !="":
                                logo = images_path + "/xttsmart.png"
                            else:
                                logo = logo
                            xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
def getAllChannels(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'itv', 
        'action' : 'get_all_channels',
        'JsHttpRequest' : '1-xml'})
    try:
        results = info['js']['data'];
        try:
            epgget = xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
        except: pass
        for i in results:
            name = i["name"]
            ch_id = i["id"]
            cmd = "http://localhost/ch/"+ch_id+"_"
            logo 	= i["logo"]
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            _s1 = cmd.split(' ');	
            cmd = _s1[0];
            if len(_s1)>1:
                cmd = _s1[1];
            epghits = []
            try:
                epgtime = epgget[ch_id]
                for epggelen in epgtime:
                    try:
                        if not epggelen['t_time'] !="":
                            pass
                        else:
                            tarih = "[B][COLOR yellow]"+epggelen['on_date']+"[/COLOR][/B]"
                            epghits.append((tarih))
                    except: pass
                    
                    try:
                        if not epggelen['name'] !="":
                            pass
                        else:
                            program = "[B][COLOR blue]Program : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['name']+"[/COLOR][/B]"
                            epghits.append((program))
                    except: pass
                    
                    try:
                        if not epggelen['t_time'] !="":
                            pass
                        else:
                            zaman = "[B][COLOR blue]Başlangıç : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time']+"[/COLOR][/B] - [B][COLOR blue]Bitiş : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time_to']+"[/COLOR][/B]"
                            epghits.append((zaman))
                    except: pass
                    
                    try:
                        if not epggelen['descr'] !="" or not epggelen['descr'] !="\n" or not epggelen['descr'] !=" ":
                            pass
                        else:
                            konu = "[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['descr']+"[/COLOR][/B]"
                            epghits.append((konu))
                    except: pass
                    # print (epggelen['on_date']+" - "+epggelen['t_time']+" - "+epggelen['t_time_to']+"\n"+epggelen['name']+"\n"+epggelen['descr']+"\n")
            except: pass
            if not epghits != []:
                labels = "Bilgi Eklenmemiş"
            else:
                labels = replace_fix(str(epghits))
            xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
    except:
        try:
            for i in results:
                name = i["name"]
                ch_id = i["id"]
                cmd = "http://localhost/ch/"+ch_id+"_"
                logo 	= i["logo"]
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                _s1 = cmd.split(' ');	
                cmd = _s1[0];
                if len(_s1)>1:
                    cmd = _s1[1];
                xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
        except:
            return playList.clear(exit())
    xttplaymac(filename,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmc.executebuiltin("Container.SetViewMode(54)")
def testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'watchdog',
        'action' : 'get_events',
        'init' : '0',
        'cur_play_type' : '1',
        'event_active_id' : '0'})
        
    if not playinfo !="itv&action":
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'itv',
            'action' : 'create_link',
            'cmd' : str(fix)});
    else:
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod',
            'action' : 'create_link',
            'cmd' : str(fix)});
    cmd = info['js']['cmd'];
    # print (cmd)
    s = cmd.split(' ');
    url = s[0];
    if len(s)>1:
        url = s[1];
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', infoLabels={"plot": str(metainfo)})
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
def testplayermeta(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'watchdog',
        'action' : 'get_events',
        'init' : '0',
        'cur_play_type' : '1',
        'event_active_id' : '0'})
    if not playinfo !="itv&action":
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'itv',
            'action' : 'create_link',
            'cmd' : str(fix)});
    else:
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod',
            'action' : 'create_link',
            'cmd' : str(fix)});
    cmd = info['js']['cmd'];
    s = cmd.split(' ');
    url = s[0];
    if len(s)>1:
        url = s[1];
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', infoLabels={"plot": str(metainfo)})
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
def xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):	
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    infoepg = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'itv', 
        'action' : 'get_epg_info',
        'period' : '6',
        'JsHttpRequest' : '1-xml'})
    resultsepg = infoepg['js']['data'];
    return resultsepg
def handshake(panelurl,mac,timezone):
    tokenkey = ""
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'stb', 
        'action' : 'handshake',
        'JsHttpRequest' : '1-xml'})
    tokenkey = info['js']['token']
    return tokenkey
def getProfile(panelurl,mac,tokenkey,timezone):
    values = {
        'type' : 'stb', 
        'action' : 'get_profile',
        'hd' : '1',
        'ver' : 'ImageDescription:%200.2.18-r11-pub-254;%20ImageDate:%20Wed%20Mar%2018%2018:09:40%20EET%202015;%20PORTAL%20version:%204.9.14;%20API%20Version:%20JS%20API%20version:%20331;%20STB%20API%20version:%20141;%20Player%20Engine%20version:%200x572',
        'num_banks' : '1',
        'stb_type' : 'MAG254',
        'image_version' : '218',
        'auth_second_step' : '0',
        'hw_version' : '2.6-IB-00',
        'not_valid_token' : '0',
        'JsHttpRequest' : '1-xml'}
    info = Datasearch(panelurl,mac,tokenkey,timezone,values);
    passfalse = info['js']['password']
    if not passfalse !="":
        values = {
            'type' : 'stb', 
            'action' : 'get_profile'}
        info = Datasearch(panelurl,mac,tokenkey,timezone,values);
        timezone = info['js']['default_timezone']
        return timezone
    else:
        timezone = info['js']['default_timezone']
        return timezone
def Datasearch(panelurl,mac,tokenkey,timezone,values):
    if not tokenkey !="":
        tokenkey = ""
    else:
        tokenkey = tokenkey
    if not timezone !="":
        timezone = 'America/Chicago';
    else:
        timezone = timezone
    user_agent 	= 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3';
    try:
        if not tokenkey !="":
            headers = {
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac+ '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet'};
        else:
            headers = { 
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac + '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet',
                'Authorization' : 'Bearer ' + tokenkey };

        load = "/server/load.php"
        data = urllib.parse.urlencode(values)
        rs = requests.get(panelurl + load + '?' + data, headers=headers)
        return rs.json()
    except:
        return playList.clear(exit())
######################################
def xttplaymac(filename,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&fileName="+urllib.parse.quote_plus(filename)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def xttplaymeta(filename,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"plot": str(metainfo)})
    liz.setProperty('fanart_image', thumbnail or thumbfolder) or ("IsPlayable", "true")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&fileName="+urllib.parse.quote_plus(filename)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)+"&metainfo="+urllib.parse.quote_plus(str(metainfo))
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def replace_fix(x):
    x=x.replace("\\n", "").replace("\n", "").replace("', '", "\n").replace('", "', "\n").replace('\', "', "\n").replace('", \'', "\n").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace('Monday', "Pazartesi").replace('Tuesday', "Salı").replace('Wednesday', "Çarşamba").replace('Thursday', "Perşembe").replace('Friday', "Cuma").replace('Saturday', "Cumartesi").replace('Sunday', "Pazar")
    return x