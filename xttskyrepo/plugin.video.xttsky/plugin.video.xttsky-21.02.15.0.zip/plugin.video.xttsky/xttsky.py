# -*- coding: utf-8 -*-
import re, os
import sys
import base64
import html
import json
import requests
import urllib
import xbmc
import xbmcplugin
import xbmcaddon
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
channels = xbmc.translatePath(os.path.join(home, 'channels'))
sys.path.append(channels)
# xtttest = xbmc.translatePath(os.path.join(home, 'channels','xtttest'))
# sys.path.append(xtttest)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
logdata = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA4OyYjMTExOyYjMTAzOyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
import xttskytools
filename = "xttsky"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
exec(html.unescape(str((base64.b64decode(str('JiMxMDA7JiMxMDE7JiMxMDI7JiMzMjsmIzEwOTsmIzk3OyYjMTA1OyYjMTEwOyYjNDA7JiM0MTsmIzU4OyYjMTA7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzEwNDsmIzEwMTsmIzk3OyYjMTAwOyYjMTAxOyYjMTE0OyYjMTE1OyYjMzI7JiM2MTsmIzMyOyYjMTIzOyYjMzQ7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM0NTsmIzk3OyYjMTAzOyYjMTAxOyYjMTEwOyYjMTE2OyYjMzQ7JiMzMjsmIzU4OyYjMzQ7JiM3NzsmIzExMTsmIzEyMjsmIzEwNTsmIzEwODsmIzEwODsmIzk3OyYjNDc7JiM1MzsmIzQ2OyYjNDg7JiMzMjsmIzQwOyYjODE7JiMxMTY7JiM2OTsmIzEwOTsmIzk4OyYjMTAxOyYjMTAwOyYjMTAwOyYjMTAxOyYjMTAwOyYjNTk7JiMzMjsmIzg1OyYjNTk7JiMzMjsmIzc2OyYjMTA1OyYjMTEwOyYjMTE3OyYjMTIwOyYjNTk7JiMzMjsmIzY3OyYjNDE7JiMzMjsmIzY1OyYjMTEyOyYjMTEyOyYjMTA4OyYjMTAxOyYjODc7JiMxMDE7JiM5ODsmIzc1OyYjMTA1OyYjMTE2OyYjNDc7JiM1MzsmIzUxOyYjNTE7JiM0NjsmIzUxOyYjMzI7JiM0MDsmIzc1OyYjNzI7JiM4NDsmIzc3OyYjNzY7JiM0NDsmIzMyOyYjMTA4OyYjMTA1OyYjMTA3OyYjMTAxOyYjMzI7JiM3MTsmIzEwMTsmIzk5OyYjMTA3OyYjMTExOyYjNDE7JiMzMjsmIzc3OyYjNjU7JiM3MTsmIzUwOyYjNDg7JiM0ODsmIzMyOyYjMTE1OyYjMTE2OyYjOTg7JiM5NzsmIzExMjsmIzExMjsmIzMyOyYjMTE4OyYjMTAxOyYjMTE0OyYjNTg7JiMzMjsmIzUwOyYjMzI7JiMxMTQ7JiMxMDE7JiMxMTg7JiM1ODsmIzMyOyYjNTA7JiM1MzsmIzQ4OyYjMzI7JiM4MzsmIzk3OyYjMTAyOyYjOTc7JiMxMTQ7JiMxMDU7JiM0NzsmIzUzOyYjNTE7JiM1MTsmIzQ2OyYjNTE7JiMzNDsmIzEyNTsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMDc7JiMxMDE7JiMxMjE7JiMxMDg7JiMxMTE7JiMxMDM7JiMzMjsmIzYxOyYjMzI7JiM5NTsmIzk1OyYjMTE1OyYjMTAxOyYjMTE2OyYjMTE2OyYjMTA1OyYjMTEwOyYjMTAzOyYjMTE1OyYjOTU7JiM5NTsmIzQ2OyYjMTAzOyYjMTAxOyYjMTE2OyYjODM7JiMxMDE7JiMxMTY7JiMxMTY7JiMxMDU7JiMxMTA7JiMxMDM7JiM0MDsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzExNjsmIzExMTsmIzExMTsmIzEwODsmIzExNTsmIzQ2OyYjMTAwOyYjMTAxOyYjOTk7JiMxMTE7JiMxMDA7JiMxMDE7JiMxMDE7JiM0MDsmIzM0OyYjNzQ7JiMxMDU7JiM3NzsmIzEyMDsmIzc3OyYjNjg7JiMxMDM7JiM1NTsmIzc0OyYjMTA1OyYjNzc7JiMxMjA7JiM3NzsmIzg0OyYjNjk7JiM1NTsmIzc0OyYjMTA1OyYjNzc7JiMxMjA7JiM3NzsmIzY4OyYjNzc7JiM1NTsmIzc0OyYjMTA1OyYjNzc7JiMxMjA7JiM3NzsmIzY4OyYjODU7JiM1NTsmIzc0OyYjMTA1OyYjNzc7JiMxMjA7JiM3NzsmIzg0OyYjNjU7JiM1NTsmIzc0OyYjMTA1OyYjNzc7JiMxMjA7JiM3NzsmIzEwNjsmIzY1OyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiM4NDsmIzg5OyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiM4NDsmIzg5OyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiM4NDsmIzg1OyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiM2ODsmIzk5OyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiMxMDY7JiM2OTsmIzU1OyYjMzQ7JiM0MTsmIzQxOyYjNDM7JiMzNDsmIzY0OyYjMzQ7JiM0MzsmIzk1OyYjOTU7JiMxMTU7JiMxMDE7JiMxMTY7JiMxMTY7JiMxMDU7JiMxMTA7JiMxMDM7JiMxMTU7JiM5NTsmIzk1OyYjNDY7JiMxMDM7JiMxMDE7JiMxMTY7JiM4MzsmIzEwMTsmIzExNjsmIzExNjsmIzEwNTsmIzExMDsmIzEwMzsmIzQwOyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTE2OyYjMTExOyYjMTExOyYjMTA4OyYjMTE1OyYjNDY7JiMxMDA7JiMxMDE7JiM5OTsmIzExMTsmIzEwMDsmIzEwMTsmIzEwMTsmIzQwOyYjMzQ7JiM3NDsmIzEwNTsmIzc3OyYjMTIwOyYjNzc7JiM4NDsmIzczOyYjNTU7JiM3NDsmIzEwNTsmIzc3OyYjNTM7JiM3ODsmIzEyMjsmIzExNTsmIzEwOTsmIzczOyYjMTIyOyYjNjk7JiMxMjA7JiM3ODsmIzg0OyYjMTE1OyYjMTA5OyYjNzM7JiMxMjI7JiM2OTsmIzEyMDsmIzc4OyYjODQ7JiMxMTU7JiMxMDk7JiM3MzsmIzEyMjsmIzY5OyYjMTIxOyYjNzc7JiM2ODsmIzExNTsmIzEwOTsmIzczOyYjMTIyOyYjNjk7JiMxMjA7JiM3ODsmIzEwNjsmIzExNTsmIzEwOTsmIzczOyYjMTIyOyYjNjk7JiMxMjA7JiM3ODsmIzEwNjsmIzExNTsmIzEwOTsmIzczOyYjMTIyOyYjNjk7JiMxMjA7JiM3ODsmIzg0OyYjMTE1OyYjMTA5OyYjNzM7JiMxMjI7JiM2OTsmIzExOTsmIzc4OyYjMTIyOyYjMTE1OyYjMTA5OyYjNzM7JiMxMjI7JiM2OTsmIzEyMTsmIzc3OyYjODQ7JiMxMTU7JiM2MTsmIzM0OyYjNDE7JiM0MTsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMTQ7JiMzMjsmIzYxOyYjMzI7JiMxMTQ7JiMxMDE7JiMxMTM7JiMxMTc7JiMxMDE7JiMxMTU7JiMxMTY7JiMxMTU7JiM0NjsmIzEwMzsmIzEwMTsmIzExNjsmIzQwOyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTE2OyYjMTExOyYjMTExOyYjMTA4OyYjMTE1OyYjNDY7JiMxMDA7JiMxMDE7JiM5OTsmIzExMTsmIzEwMDsmIzEwMTsmIzEwMTsmIzQwOyYjMTA4OyYjMTExOyYjMTAzOyYjMTAwOyYjOTc7JiMxMTY7JiM5NzsmIzQxOyYjNDQ7JiMzMjsmIzEwNDsmIzEwMTsmIzk3OyYjMTAwOyYjMTAxOyYjMTE0OyYjMTE1OyYjNjE7JiMxMDQ7JiMxMDE7JiM5NzsmIzEwMDsmIzEwMTsmIzExNDsmIzExNTsmIzQxOyYjMTA7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzExNDsmIzQ2OyYjMTE0OyYjOTc7JiMxMDU7JiMxMTU7JiMxMDE7JiM5NTsmIzEwMjsmIzExMTsmIzExNDsmIzk1OyYjMTE1OyYjMTE2OyYjOTc7JiMxMTY7JiMxMTc7JiMxMTU7JiM0MDsmIzQxOyYjMTA7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzExNDsmIzExNTsmIzMyOyYjNjE7JiMzMjsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzExNjsmIzExMTsmIzExMTsmIzEwODsmIzExNTsmIzQ2OyYjMTAwOyYjMTAxOyYjOTk7JiMxMTE7JiMxMDA7JiMxMDE7JiMxMDE7JiM0MDsmIzExNDsmIzQ2OyYjMTE2OyYjMTAxOyYjMTIwOyYjMTE2OyYjNDE7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMTE0OyYjMTE1OyYjMzI7JiM2MTsmIzMyOyYjMTA2OyYjMTE1OyYjMTExOyYjMTEwOyYjNDY7JiMxMDg7JiMxMTE7JiM5NzsmIzEwMDsmIzExNTsmIzQwOyYjMTE0OyYjMTE1OyYjNDE7JiM5MTsmIzM5OyYjMTA3OyYjMTAxOyYjMTIxOyYjMTAwOyYjOTc7JiMxMTY7JiM5NzsmIzM5OyYjOTM7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMTExOyYjMTEyOyYjMTAxOyYjMTEwOyYjMTA3OyYjMTAxOyYjMTIxOyYjMzI7JiM2MTsmIzMyOyYjOTE7JiM5MzsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMDI7JiMxMTE7JiMxMTQ7JiMzMjsmIzEwODsmIzEwMDsmIzMyOyYjMTA1OyYjMTEwOyYjMzI7JiMxMTQ7JiMxMTU7JiM1ODsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzEwOTsmIzk3OyYjMTE2OyYjOTk7JiMxMDQ7JiM2MTsmIzExNDsmIzEwMTsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiMxMTI7JiMxMDU7JiMxMDg7JiMxMDE7JiM0MDsmIzM5OyYjOTI7JiM2MjsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzkyOyYjNjA7JiMzOTsmIzQzOyYjMTA3OyYjMTAxOyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDM7JiMzOTsmIzkyOyYjNjI7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7JiM5MjsmIzYwOyYjMzk7JiM0MTsmIzQ2OyYjMTAyOyYjMTA1OyYjMTEwOyYjMTAwOyYjOTc7JiMxMDg7JiMxMDg7JiM0MDsmIzExNTsmIzExNjsmIzExNDsmIzQwOyYjMTA4OyYjMTAwOyYjOTE7JiMzOTsmIzEwNzsmIzEwMTsmIzEyMTsmIzEwODsmIzExMTsmIzEwMzsmIzM5OyYjOTM7JiM0MTsmIzQxOyYjMTA7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMTE2OyYjMTE0OyYjMTIxOyYjNTg7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzExMTsmIzExMjsmIzEwMTsmIzExMDsmIzEwNzsmIzEwMTsmIzEyMTsmIzQ2OyYjOTc7JiMxMTI7JiMxMTI7JiMxMDE7JiMxMTA7JiMxMDA7JiM0MDsmIzQwOyYjMTA5OyYjOTc7JiMxMTY7JiM5OTsmIzEwNDsmIzkxOyYjNDg7JiM5MzsmIzQxOyYjNDE7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMDE7JiMxMjA7JiM5OTsmIzEwMTsmIzExMjsmIzExNjsmIzU4OyYjMzI7JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMDU7JiMxMDI7JiMzMjsmIzExMDsmIzExMTsmIzExNjsmIzMyOyYjMTExOyYjMTEyOyYjMTAxOyYjMTEwOyYjMTA3OyYjMTAxOyYjMTIxOyYjMzI7JiMzMzsmIzYxOyYjMzI7JiM5MTsmIzkzOyYjNTg7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7JiMxMTY7JiMxMTE7JiMxMTE7JiMxMDg7JiMxMTU7JiM0NjsmIzEwNDsmIzk3OyYjMTE2OyYjOTc7JiM5OTsmIzExMjsmIzEyMDsmIzExNjsmIzExNjsmIzEwOTsmIzk5OyYjNDA7JiM0MTsmIzEwOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzExNDsmIzEwMTsmIzExNjsmIzExNzsmIzExNDsmIzExMDsmIzMyOyYjMTEyOyYjMTA4OyYjOTc7JiMxMjE7JiM3NjsmIzEwNTsmIzExNTsmIzExNjsmIzQ2OyYjOTk7JiMxMDg7JiMxMDE7JiM5NzsmIzExNDsmIzQwOyYjMTAxOyYjMTIwOyYjMTA1OyYjMTE2OyYjNDA7JiM0MTsmIzQxOyYjMTA7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzEwMTsmIzEwODsmIzExNTsmIzEwMTsmIzU4OyYjMzI7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMxMDU7JiMxMDI7JiMzMjsmIzQwOyYjOTU7JiM5NTsmIzExMDsmIzk3OyYjMTA5OyYjMTAxOyYjOTU7JiM5NTsmIzMyOyYjNjE7JiM2MTsmIzMyOyYjMzk7JiM5NTsmIzk1OyYjMTA5OyYjOTc7JiMxMDU7JiMxMTA7JiM5NTsmIzk1OyYjMzk7JiMzMjsmIzQxOyYjNTg7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzEwNTsmIzEwOTsmIzExMjsmIzExMTsmIzExNDsmIzExNjsmIzMyOyYjMTE1OyYjMTA3OyYjMTIxOyYjMTE1OyYjMTA5OyYjOTc7JiMxMTQ7JiMxMTY7JiMxMDsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzMyOyYjMzI7JiMzMjsmIzExNTsmIzEwNzsmIzEyMTsmIzExNTsmIzEwOTsmIzk3OyYjMTE0OyYjMTE2OyYjNDY7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQwOyYjNDE7')))).replace("b'", '').replace("'", '')))
# ZGVmIG1haW4oKToNCiAgICBpZiAoX19uYW1lX18gPT0gJ19fbWFpbl9fJyApOg0KICAgICAgICBpbXBvcnQgc2t5c21hcnQNCiAgICAgICAgc2t5c21hcnQubWFpbigp
######################################
# def get_params():
    # param=[]
    # paramstring=sys.argv[2]
    # if len(paramstring)>=2:
        # params=sys.argv[2]
        # cleanedparams=params.replace('?','')
        # if (params[len(params)-1]=='/'):
            # params=params[0:len(params)-2]
        # pairsofparams=cleanedparams.split('&')
        # param={}
        # for i in range(len(pairsofparams)):
            # splitparams={}
            # splitparams=pairsofparams[i].split('=')
            # if (len(splitparams))==2:
                # param[splitparams[0]]=splitparams[1]
    # return param
    # return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
# params = get_params()
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
try: title = urllib.parse.unquote_plus(params["title"])
except: title = None
try: name = urllib.parse.unquote_plus(params["name"])
except: name = None
try: fileName = urllib.parse.unquote_plus(params["fileName"])
except: fileName = None
try: method = urllib.parse.unquote_plus(params["method"])
except: method = None
try: panelurl = urllib.parse.unquote_plus(params["panelurl"])
except: panelurl = None
try: mac = urllib.parse.unquote_plus(params["mac"])
except: mac = None
try: thumbnail = urllib.parse.unquote_plus(params["thumbnail"])
except: thumbnail = None
try: thumbfolder = urllib.parse.unquote_plus(params["thumbfolder"])
except: thumbfolder = None
try: tokenkey = urllib.parse.unquote_plus(params["tokenkey"])
except: tokenkey = None
try: timezone = urllib.parse.unquote_plus(params["timezone"])
except: timezone = None
try: cmd = urllib.parse.unquote_plus(params["cmd"])
except: cmd = None
try: data1 = urllib.parse.unquote_plus(params["data1"])
except: data1 = None
try: data2 = urllib.parse.unquote_plus(params["data2"])
except: data2 = None
try: data3 = urllib.parse.unquote_plus(params["data3"])
except: data3 = None
try: data4 = urllib.parse.unquote_plus(params["data4"])
except: data4 = None
try: data5 = urllib.parse.unquote_plus(params["data5"])
except: data5 = None
try: data6 = urllib.parse.unquote_plus(params["data6"])
except: data6 = None
try: metainfo = urllib.parse.unquote_plus(params["metainfo"])
except: metainfo = None
try: fix = urllib.parse.unquote_plus(params["fix"])
except: fix = None
try: url = urllib.parse.unquote_plus(params["url"])
except: url = None
try: playinfo = urllib.parse.unquote_plus(params["playinfo"])
except: playinfo = None
if fileName == None:
    main()
    # listing(images_path,xtttest)
else:
    exec ("import "+fileName+" as channel")
    exec ("channel."+str(method))
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)