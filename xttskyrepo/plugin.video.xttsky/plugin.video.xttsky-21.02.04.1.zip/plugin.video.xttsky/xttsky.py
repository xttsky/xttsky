# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import urllib.parse
import html
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import base64
import requests
import xttmcsrc, htmlxmltest
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
channels = xbmc.translatePath(os.path.join(home, 'channels'))
sys.path.append(channels)
xtttest = xbmc.translatePath(os.path.join(home, 'channels','xtttest'))
sys.path.append(xtttest)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
FILENAME = "xttsky"
info_hml ='JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMDk7JiM5OTsmIzEwNTsmIzExMDsmIzEwMjsmIzExMTsmIzQ2OyYjMTIwOyYjMTA5OyYjMTA4Ow=='
info_xml ='E:/xttmc/xttmc/xttsky/xttskyxml/xttmcinfo.xml'
logdata = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTA4OyYjMTExOyYjMTAzOyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjMTA4OyYjMTExOyYjMTAzOyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
dataurl = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjNDc7JiMxMDk7JiM5NzsmIzEwNTsmIzExMDsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
dataxml = "JiM2OTsmIzU4OyYjNDc7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMDk7JiM5OTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTA5OyYjOTk7JiM0NzsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTsmIzQ3OyYjMTIwOyYjMTE2OyYjMTE2OyYjMTE1OyYjMTA3OyYjMTIxOyYjMTIwOyYjMTA5OyYjMTA4OyYjNDc7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDY7JiMxMjA7JiMxMDk7JiMxMDg7"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
maininfohtmlxmltest = htmlxmltest.maininfohtmlxml
def main():
    # datacp()
    insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = decodee(str(r.text))
    # print (rs)
    # print (str(json.loads(rs)['paneurl']))
    # js = str(json.loads(rs)['paneurl'][0]['datalog'])
    js = str(str(json.loads(rs)['keydata'])).strip('[]')
    match=re.compile('(?:\"|\')keylog(?:\"|\')\:\s*(?:\"|\')\>xttsky\<'+keylog+'\>xttsky\<(?:\"|\')').findall(str(js))
    if not match != []:
        hatacpxttmc()
        return playList.clear(exit())
    else: 
        return mainnet()
        # return mainxml()
def mainnet():
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    if __settings__.getSetting("PanelAcKapat") == "false":
        pass
    else:
        r = requests.get(decodee(dataurl), headers=headers)
        r.raise_for_status()
        # print (r.text)
        if '.' in r.text:
            # print (r.text)
            jr = r.json()['data']
            for panelsayisi in range(len(jr)):
                panel = jr[panelsayisi]
                # print (panel)
                group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,macinfo)",str(panel['datalog']),thumbnail,"","",str(panel['datamac']),"","","")
        else:
            # rs = decodee((r.text).replace("[", '').replace("]", '').replace("b'", '').replace("'", '').replace(" ", ''))
            rs = decodee(str(r.text))
            # print (rs)
            # print (str(json.loads(rs)['paneurl']))
            # js = str(json.loads(rs)['paneurl'][0]['datalog'])
            js = str(str(json.loads(rs)['data'])).strip('[]')
            # print (js)
            match=re.compile('\{(?:\"|\')\s*datalog\s*(?:\"|\')\s*\:\s*(?:\"|\')\s*(.*?)\s*(?:\"|\')\s*\,\s*(?:\"|\')\s*datamac\s*(?:\"|\')\s*\: \'00\:1(?:A|a)?\:79\:([0-9A-Za-z_\-:]+)\s*(?:\"|\')\s*}').findall(str(js))
            for panelsayisi in range(len(match)):
                # print (match[panelsayisi][0])
                group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,macinfo)",str(match[panelsayisi][0]),thumbnail,"","",str('00:1A:79:' + match[panelsayisi][1]),"","","")
                
    ################## panelozellist ######################
    if __settings__.getSetting("PanelListeAcKapat") == "false":
        pass
    else:
        if __settings__.getSetting("panel1onoff") == "true":
            host1 = __settings__.getSetting("host1")
            mac1 = __settings__.getSetting("mac1")
        else:
            host1 = ""
            mac1 = ""
        if __settings__.getSetting("panel2onoff") == "true":
            host2 = __settings__.getSetting("host2")
            mac2 = __settings__.getSetting("mac2")
        else:
            host2 = ""
            mac2 = ""
        if __settings__.getSetting("panel3onoff") == "true":
            host3 = __settings__.getSetting("host3")
            mac3 = __settings__.getSetting("mac3")
        else:
            host3 = ""
            mac3 = ""
        if __settings__.getSetting("panel4onoff") == "true":
            host4 = __settings__.getSetting("host4")
            mac4 = __settings__.getSetting("mac4")
        else:
            host4 = ""
            mac4 = ""
        if __settings__.getSetting("panel5onoff") == "true":
            host5 = __settings__.getSetting("host5")
            mac5 = __settings__.getSetting("mac5")
        else:
            host5 = ""
            mac5 = ""
        if __settings__.getSetting("panel6onoff") == "true":
            host6 = __settings__.getSetting("host6")
            mac6 = __settings__.getSetting("mac6")
        else:
            host6 = ""
            mac6 = ""
        if __settings__.getSetting("panel7onoff") == "true":
            host7 = __settings__.getSetting("host7")
            mac7 = __settings__.getSetting("mac7")
        else:
            host7 = ""
            mac7 = ""
        if __settings__.getSetting("panel8onoff") == "true":
            host8 = __settings__.getSetting("host8")
            mac8 = __settings__.getSetting("mac8")
        else:
            host8 = ""
            mac8 = ""
        if __settings__.getSetting("panel9onoff") == "true":
            host9 = __settings__.getSetting("host9")
            mac9 = __settings__.getSetting("mac9")
        else:
            host9 = ""
            mac9 = ""
        if __settings__.getSetting("panel10onoff") == "true":
            host10 = __settings__.getSetting("host10")
            mac10 = __settings__.getSetting("mac10")
        else:
            host10 = ""
            mac10 = ""
        if __settings__.getSetting("panel11onoff") == "true":
            host11 = __settings__.getSetting("host11")
            mac11 = __settings__.getSetting("mac11")
        else:
            host11 = ""
            mac11 = ""
        if __settings__.getSetting("panel12onoff") == "true":
            host12 = __settings__.getSetting("host12")
            mac12 = __settings__.getSetting("mac12")
        else:
            host12 = ""
            mac12 = ""
        if __settings__.getSetting("panel13onoff") == "true":
            host13 = __settings__.getSetting("host13")
            mac13 = __settings__.getSetting("mac13")
        else:
            host13 = ""
            mac13 = ""
        if __settings__.getSetting("panel14onoff") == "true":
            host14 = __settings__.getSetting("host14")
            mac14 = __settings__.getSetting("mac14")
        else:
            host14 = ""
            mac14 = ""
        if __settings__.getSetting("panel15onoff") == "true":
            host15 = __settings__.getSetting("host15")
            mac15 = __settings__.getSetting("mac15")
        else:
            host15 = ""
            mac15 = ""
        settingspanel = []
        data = [
        {"datalog": host1, "datamac": mac1},
        {"datalog": host2, "datamac": mac2},
        {"datalog": host3, "datamac": mac3},
        {"datalog": host4, "datamac": mac4},
        {"datalog": host5, "datamac": mac5},
        {"datalog": host6, "datamac": mac6},
        {"datalog": host7, "datamac": mac7},
        {"datalog": host8, "datamac": mac8},
        {"datalog": host9, "datamac": mac9},
        {"datalog": host10, "datamac": mac10},
        {"datalog": host11, "datamac": mac11},
        {"datalog": host12, "datamac": mac12},
        {"datalog": host13, "datamac": mac13},
        {"datalog": host14, "datamac": mac14},
        {"datalog": host15, "datamac": mac15}
        ]
        for panelsayisi in range(len(data)):
            panel = data[panelsayisi]['datalog']
            # print (panel)
            if not data[panelsayisi]['datalog'] != "":
                pass
            else:
                settingspanel.append((data[panelsayisi]))
        if settingspanel == []:
            pass
        else:
            for panelok in range(len(settingspanel)):
                group_title = 'SMART PANEL LİSTE  ' + "[B][COLOR red]"+str(panelok+1)+"[/COLOR]"
                thumbnail = images_path + "/xttsmarttv.png"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,macinfo)",str(settingspanel[panelok]['datalog']),thumbnail,"","",str(settingspanel[panelok]['datamac']),"","","")
    ################## m3ulist ####################
    if __settings__.getSetting("M3uListeAcKapat") == "false":
        pass
    else:
        if __settings__.getSetting("m3u1onoff") == "true":
            m3u1 = __settings__.getSetting("m3u1")
        else:
            m3u1 = ""
        if __settings__.getSetting("m3u2onoff") == "true":
            m3u2 = __settings__.getSetting("m3u2")
        else:
            m3u2 = ""
        if __settings__.getSetting("m3u3onoff") == "true":
            m3u3 = __settings__.getSetting("m3u3")
        else:
            m3u3 = ""
        settingsm3u = []
        datam3u = [
        {"m3ulog": m3u1},
        {"m3ulog": m3u2},
        {"m3ulog": m3u3},
        ]
        for m3usayisi in range(len(datam3u)):
            m3u = datam3u[m3usayisi]['m3ulog']
            print (m3u)
            if not datam3u[m3usayisi]['m3ulog'] != "":
                pass
            else:
                settingsm3u.append((datam3u[m3usayisi]))
        if settingsm3u == []:
            pass
        else:
            for m3uok in range(len(settingsm3u)):
                group_title = 'SMART M3U LİSTE  ' + "[B][COLOR red]"+str(m3uok+1)+"[/COLOR]"
                xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "m3ukategori(url)",str(settingsm3u[m3uok]['m3ulog']),"","xttsmarttv","","","","","")
    if __settings__.getSetting("bilgipaneli") == "false":
        pass
    else:
        xttplaymac(FILENAME,"[B][COLOR lightblue] Info..[COLOR yellow]![/COLOR] [/COLOR][/B]", "infomain()","","","xttmcinfo","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def infomain():
    exec(maininfohtmlxmltest)
    # infohtml()
    # infoxml()
    # return infohtml()
    # return infoxml()
def infohtml():
    try:
        headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
        r = requests.get(decodee(info_hml), headers=headers)
        r.raise_for_status()
        infolink = decodee(str(r.text))
        label = '%s - %s - %s' % (xbmc.getLocalizedString(24054), xbmcaddon.Addon().getAddonInfo('name'), "Son Guncelleme Tarih ve Versiyonu " + xbmcaddon.Addon().getAddonInfo('version'))
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(50)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                win.getControl(1).setLabel(label)
                win.getControl(5).setText(infolink)
                retry = 0
            except:
                retry -= 1
        return exit()
    except:
        return exit()
def infoxml():
    try:
        gf = open(info_xml, 'r', encoding='utf-8')
        infolink = gf.read()
        label = '%s - %s - %s' % (xbmc.getLocalizedString(24054), xbmcaddon.Addon().getAddonInfo('name'), "Son Guncelleme Tarih ve Versiyonu " + xbmcaddon.Addon().getAddonInfo('version'))
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(50)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                win.getControl(1).setLabel(label)
                win.getControl(5).setText(infolink)
                retry = 0
            except:
                retry -= 1
        return exit()
    except:
        return exit()
def m3ukategori(url):
    bolum=['[COLOR lightblue][B]KANAL LISTESI[/B][/COLOR]','[COLOR darkgray][B]KATEGORI[/B][/COLOR]']
    maintv=['m3ulisteleme','m3ugrup']
    ret = xbmcgui.Dialog().select('[COLOR white][B]IZLEME SECENEKLERI...[/B][/COLOR]', bolum)
    js= maintv[ret]
    if 'm3ulisteleme' in js:
        return m3ulisteleme(str(url))
    else:
        return m3ugrup(str(url))
    return playList.clear(exit())
def m3ugrup(url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    sonuclarm3u = []
    match=re.compile('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="(.*?)".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)').findall(str(r.text))
    for gelenler in match:
        sonuclarm3u.append((gelenler[2]))
    list2 = []
    for i in sonuclarm3u:
      if i not in list2:
        list2.append(i)
    for grouptitle in list2:
        logo = images_path + "/xttsmart.png"
        xttplaymac(FILENAME,str(grouptitle),"m3ugruplist(name,url)",str(url),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def m3ugruplist(name,url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    match=re.compile('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="'+str(name)+'".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)').findall(str(r.text))
    for match1 in match:
        if not match1[1] !="":
            logo = images_path + "/xttsmart.png"
        else:
            logo = str(match1[1])
        xttplaymac(FILENAME,str(match1[0]),"xttskyplayer(name,url,thumbnail)","http://"+str(match1[2]),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def m3ulisteleme(url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    for match in re.finditer('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="(.*?)".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)', str(r.text)):
        if not match[2] !="":
            logo = images_path + "/xttsmart.png"
        else:
            logo = str(match[2])
        xttplaymac(FILENAME,str(match[1]),"xttskyplayer(name,url,thumbnail)","http://"+str(match[4]),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def mainxml():
    gf = open(decodee(dataxml), 'r', encoding='utf-8')
    # data = gf.read()
    datacap = json.loads(gf.read())
    # link = link.encode('utf-8', 'ignore')
    data = datacap['paneurl']
    # print (data)
    for panelsayisi in range(len(data)):
        panel = data[panelsayisi]
        # print (panel)
        group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
        thumbnail = images_path + "/xttsmarttv.png"
        xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,macinfo)",str(panel['panelhost']),thumbnail,"","",str(panel['panelmac']),"","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def maintest():
    data = [
ICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9pc3RhbmJ1bDE0NTMuYml6OjgwODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6QTI6ODI6RUIifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9pcHR2dHIxLm5ldDo4MDgwIiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjI4OjdFOjQ3In0sCiAgICB7InBhbmVsaG9zdCI6ICJodHRwOi8vZWxpdDY0LmNvbTo2NDY0IiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjAwOjRFOjVCIn0sCiAgICB7InBhbmVsaG9zdCI6ICJodHRwOi8vY2FydGlwdHYuY29tOjgwODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6MDA6MDg6RDkifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly92aXAuYm1idHYubWU6MTUwMDAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6NkY6NjU6RTQifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly9kZGlwdHYubWw6ODAiLCAicGFuZWxtYWMiOiAiMDA6MUE6Nzk6MDA6RDM6RUEifSwKICAgIHsicGFuZWxob3N0IjogImh0dHA6Ly90aXZpeHMuY29tOjgwIiwgInBhbmVsbWFjIjogIjAwOjFBOjc5OjFBOjAyOkFEIn0
    ]
    for panelsayisi in range(len(data)):
        panel = data[panelsayisi]
        # print (panel)
        group_title = 'SMART  ' + "[B][COLOR red]"+str(panelsayisi+1)+"[/COLOR]"
        thumbnail = images_path + "/xttsmarttv.png"
        xttplaymac(FILENAME,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "panelmac(url,macinfo)",str(panel['panelhost']),thumbnail,"","",str(panel['panelmac']),"","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def panelmac(url,macinfo):
    mac = str(macinfo)
    panelurl = str(url)
    thumbnaillive = images_path + "/xttsmarttv.png"
    thumbnailvod = images_path + "/xttsine.png"
    xttplaymac(FILENAME,str("LIVE"), "xttsky(url,macinfo,actionplayer)",str(panelurl),thumbnaillive,"","",str(macinfo),"","","itv&action")
    xttplaymac(FILENAME,str("VOD"), "xttsky(url,macinfo,actionplayer)",str(panelurl),thumbnailvod,"","",str(macinfo),"","","vod&action")
    # xttplaymac(FILENAME,str("LIVE"), "xttsky2(url,macinfo,actionplayer)",str(panelurl),thumbnaillive,"","",str(macinfo),"","","itv&action")
    # xttplaymac(FILENAME,str("VOD"), "xttsky2(url,macinfo,actionplayer)",str(panelurl),thumbnailvod,"","",str(macinfo),"","","vod&action")
    xbmc.executebuiltin("Container.SetViewMode(500)")
########################  XTTSKY  ###########################
def xttsky(url,macinfo,actionplayer):
    mac = str(macinfo)
    panelurl = str(url)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":"Europe/Athens"}
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    if not actionplayer !="itv&action":
        anamenuurl = str(panelurl) + "/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
        actionplayer = "itv&action"
    else:
        anamenuurl = str(panelurl) + "/portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml&mac=" + str(macinfo)
        actionplayer = "vod&action"
    try:
        ars = requests.get(anamenuurl, cookies=cookies, headers=headers)
        for listeler in ars.json()['js']:
            if  not listeler['id'] != '*':
                pass
            else:
                if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                    if __settings__.getSetting("yetiskinackapat") == "true":
                        idler = listeler['id']
                        title= listeler['title']
                        thumbnaillive = images_path + "/xttmctv.png"
                        xttplaymac(FILENAME,title, "x18xttskytopla(url,fix,macinfo,actionplayer)",url,thumbnaillive,"",str(idler),str(macinfo),"","",actionplayer)
                    else:
                        pass
                else:
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "xttskytopla(url,fix,macinfo,actionplayer)",url,thumbnaillive,"",str(idler),str(macinfo),"","",actionplayer)
        xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
        xbmc.executebuiltin("Container.SetViewMode(500)")
    except:
        return xttsky2(panelurl,macinfo,actionplayer)
def xttskytopla(url,fix,macinfo,actionplayer):
    fix = str(fix)
    mac = str(macinfo)
    panelurl = str(url)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":"Europe/Athens"}
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    for pagenext in range(1, 501):
        if not actionplayer !="itv&action":
            get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
            actionplayer = "itv&action"
        else:
            get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
            actionplayer = "vod&action"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        playlistgenre = rs.json()['js']['data']
        if not playlistgenre !=[]:
            break
        else:
            for listeler in playlistgenre:
                name = listeler['name']
                cmd = listeler['cmd']
                if not actionplayer !="itv&action":
                    logo = listeler['logo']
                else:
                    logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                xttplaymac(FILENAME,name, "xttskyplay(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
            xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def x18xttskytopla(url,fix,macinfo,actionplayer):
    fix = str(fix)
    mac = str(macinfo)
    panelurl = str(url)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":"Europe/Athens"}
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            for pagenext in range(1, 501):
                if not actionplayer !="itv&action":
                    get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                    actionplayer = "itv&action"
                else:
                    get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                    actionplayer = "vod&action"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                playlistgenre = rs.json()['js']['data']
                if not playlistgenre !=[]:
                    break
                else:
                    for listeler in playlistgenre:
                        name = listeler['name']
                        cmd = listeler['cmd']
                        if not actionplayer !="itv&action":
                            logo = listeler['logo']
                        else:
                            logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "xttskyplay(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                    xbmc.executebuiltin("Container.SetViewMode(500)")
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                for pagenext in range(1, 501):
                    if not actionplayer !="itv&action":
                        get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                        actionplayer = "itv&action"
                    else:
                        get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                        actionplayer = "vod&action"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    playlistgenre = rs.json()['js']['data']
                    if not playlistgenre !=[]:
                        break
                    else:
                        for listeler in playlistgenre:
                            name = listeler['name']
                            cmd = listeler['cmd']
                            if not actionplayer !="itv&action":
                                logo = listeler['logo']
                            else:
                                logo = listeler['screenshot_uri']
                            if not logo !="":
                                logo = images_path + "/xttsmart.png"
                            else:
                                logo = logo
                            xttplaymac(FILENAME,name, "xttskyplay(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
            else:
                sifrehatasi()
                return playList.clear(exit())
def xttskyplay(name,url,thumbnail,fix,macinfo,actionplayer):
    fix = str(fix)
    mac = str(macinfo)
    panelurl = str(url)
    cookies = {"mac":mac, "stb_lang":"en", "timezone":"Europe/Athens"}
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    if not actionplayer !="itv&action":
        get_genres = str(panelurl) + "/portal.php?type=itv&action=create_link&cmd="+str(fix)+"&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    else:
        get_genres = str(panelurl) + "/portal.php?type=vod&action=create_link&cmd="+fix+"&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    return xttskyplayer(name,jrs,thumbnail)
    # listitem = xbmcgui.ListItem(name)
    # listitem.setArt({'thumb': thumbnail})
    # listitem.setInfo('video', {'name': name })
    # playList.add(jrs,listitem=listitem)
    # xbmcPlayer.play(playList)
    # return playList.clear(exit())
########################  XTTSKY2  ###########################
def xttsky2(url,macinfo,actionplayer):
    mac = str(macinfo)
    panelurl = str(url)
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    tokentext = jr['js']['token']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    default_timezone = rs.json()['js']['default_timezone']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    if not actionplayer !="itv&action":
        anamenuurl = str(panelurl) + "/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
        actionplayer = "itv&action"
    else:
        anamenuurl = str(panelurl) + "/portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml&mac=" + str(macinfo)
        actionplayer = "vod&action"
    ars = requests.get(anamenuurl, cookies=cookies, headers=headers)
    for listeler in ars.json()['js']:
        if  not listeler['id'] != '*':
            pass
        else:
            if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                if __settings__.getSetting("yetiskinackapat") == "true":
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(FILENAME,title, "x18xttskytopla2(url,fix,macinfo,actionplayer)",url,thumbnaillive,"",str(idler),str(macinfo),"","",actionplayer)
                else:
                    pass
            else:
                idler = listeler['id']
                title= listeler['title']
                thumbnaillive = images_path + "/xttmctv.png"
                xttplaymac(FILENAME,title, "xttskytopla2(url,fix,macinfo,actionplayer)",url,thumbnaillive,"",str(idler),str(macinfo),"","",actionplayer)
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskytopla2(url,fix,macinfo,actionplayer):
    mac = str(macinfo)
    panelurl = str(url)
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    tokentext = jr['js']['token']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    default_timezone = rs.json()['js']['default_timezone']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    fix = str(fix)
    for pagenext in range(1, 501):
        if not actionplayer !="itv&action":
            get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
            actionplayer = "itv&action"
        else:
            get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
            actionplayer = "vod&action"
        rs = requests.get(get_genres, cookies=cookies, headers=headers)
        playlistgenre = rs.json()['js']['data']
        if not playlistgenre !=[]:
            break
        else:
            for listeler in playlistgenre:
                name = listeler['name']
                cmd = listeler['cmd']
                if not actionplayer !="itv&action":
                    logo = listeler['logo']
                else:
                    logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                xttplaymac(FILENAME,name, "xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
            xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskytopla3(url,fix,macinfo,actionplayer):
    mac = str(macinfo)
    panelurl = str(url)
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    tokentext = jr['js']['token']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    default_timezone = rs.json()['js']['default_timezone']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    fix = str(fix)
    if not actionplayer !="itv&action":
        for pagenext in range(1, 501):
            get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
            actionplayer = "itv&action"
            rs = requests.get(get_genres, cookies=cookies, headers=headers)
            playlistgenre = rs.json()['js']['data']
            if not playlistgenre !=[]:
                break
            else:
                for listeler in playlistgenre:
                    name = listeler['name']
                    cmd = listeler['cmd']
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    else:
        for pagenext in range(1, 501):
            get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
            actionplayer = "vod&action"
            rs = requests.get(get_genres, cookies=cookies, headers=headers)
            playlistgenre = rs.json()['js']['data']
            if not playlistgenre !=[]:
                break
            else:
                for listeler in playlistgenre:
                    name = listeler['name']
                    cmd = listeler['cmd']
                    logo = listeler['screenshot_uri']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    xttplaymac(FILENAME,name, "xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def x18xttskytopla2(url,fix,macinfo,actionplayer):
    mac = str(macinfo)
    panelurl = str(url)
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
            r = requests.get(tokenurl, cookies=cookies, headers=headers)
            r.raise_for_status()
            tokentext = r.json()['js']['token']
            cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
            headers = {"Authorization": "Bearer "+tokentext}
            profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
            rs = requests.get(profile, cookies=cookies, headers=headers)
            default_timezone = rs.json()['js']['default_timezone']
            cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
            for pagenext in range(1, 501):
                if not actionplayer !="itv&action":
                    get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                    actionplayer = "itv&action"
                else:
                    get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                    actionplayer = "vod&action"
                rs = requests.get(get_genres, cookies=cookies, headers=headers)
                playlistgenre = rs.json()['js']['data']
                if not playlistgenre !=[]:
                    break
                else:
                    for listeler in playlistgenre:
                        name = listeler['name']
                        cmd = listeler['cmd']
                        if not actionplayer !="itv&action":
                            logo = listeler['logo']
                        else:
                            logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(FILENAME,name, "xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                    xbmc.executebuiltin("Container.SetViewMode(500)")
            xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
                r = requests.get(tokenurl, cookies=cookies, headers=headers)
                r.raise_for_status()
                tokentext = r.json()['js']['token']
                cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
                headers = {"Authorization": "Bearer "+tokentext}
                profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
                rs = requests.get(profile, cookies=cookies, headers=headers)
                default_timezone = rs.json()['js']['default_timezone']
                cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
                for pagenext in range(1, 501):
                    if not actionplayer !="itv&action":
                        get_genres = str(panelurl) + "/portal.php?type=itv&action=get_ordered_list&genre="+str(fix)+"&force_ch_link_check=&fav=0&sortby=number&hd=0&p="+str(pagenext)+"&JsHttpRequest=1-xml&from_ch_id=0"
                        actionplayer = "itv&action"
                    else:
                        get_genres = str(panelurl) + "/portal.php?type=vod&action=get_ordered_list&category="+str(fix)+"&movie_id=0&season_id=0&episode_id=0&force_ch_link_check=&fav=0&sortby=added&hd=0&not_ended=0&p="+str(pagenext)+"&JsHttpRequest=1-xml"
                        actionplayer = "vod&action"
                    rs = requests.get(get_genres, cookies=cookies, headers=headers)
                    playlistgenre = rs.json()['js']['data']
                    if not playlistgenre !=[]:
                        break
                    else:
                        for listeler in playlistgenre:
                            name = listeler['name']
                            cmd = listeler['cmd']
                            if not actionplayer !="itv&action":
                                logo = listeler['logo']
                            else:
                                logo = listeler['screenshot_uri']
                            if not logo !="":
                                logo = images_path + "/xttsmart.png"
                            else:
                                logo = logo
                            xttplaymac(FILENAME,name, "xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer)",panelurl,logo,"",str(cmd),str(mac),"","",actionplayer)
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                xttplaymac(FILENAME,"ANA MENU", "mainnet()","",images_path + "/anasayfa.png","","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
            else:
                sifrehatasi()
                return playList.clear(exit())
def xttskyplayer2(name,url,thumbnail,fix,macinfo,actionplayer):
    fix = str(fix)
    mac = str(macinfo)
    panelurl = str(url)
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    tokenurl = str(panelurl) + "/portal.php?action=handshake&type=stb&token=&mac=" + str(macinfo)
    r = requests.get(tokenurl, cookies=cookies, headers=headers)
    r.raise_for_status()
    jr = r.json()
    tokentext = jr['js']['token']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":""}
    headers = {"Authorization": "Bearer "+tokentext}
    profile = str(panelurl) + "/portal.php?type=stb&action=get_profile"
    rs = requests.get(profile, cookies=cookies, headers=headers)
    default_timezone = rs.json()['js']['default_timezone']
    cookies = {"mac":mac, "stb_lang":"en", "timezone":default_timezone}
    if not actionplayer !="itv&action":
        get_genres = str(panelurl) + "/portal.php?type=itv&action=create_link&cmd="+str(fix)+"&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    else:
        get_genres = str(panelurl) + "/portal.php?type=vod&action=create_link&cmd="+fix+"&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
    rs = requests.get(get_genres, cookies=cookies, headers=headers)
    jrs = rs.json()['js']['cmd'].replace('ffmpeg ', '')
    return xttskyplayer(name,jrs,thumbnail)
    # listitem = xbmcgui.ListItem(name)
    # listitem.setArt({'thumb': thumbnail})
    # listitem.setInfo('video', {'name': name })
    # playList.add(jrs,listitem=listitem)
    # xbmcPlayer.play(playList)
    # return playList.clear(exit())
def xttskyplayer(name,jrs,thumbnail):
    # print ('gelenurl1', url)
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', {'name': name })
    playList.add(jrs,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
    # listitem = xbmcgui.ListItem(name)
    # listitem.setArt({'thumb': thumbnail or thumbfolder})
    # listitem.setInfo('video',{'name': name, 'thumb': thumbnail or thumbfolder})
    # playList.add(url,listitem=listitem)
    # xbmcPlayer.play(playList)
    # return playList.clear(exit())
##################################betikler############################################
def replace_ascii(k):
        y= ''+';&#'.join(str(ord(c)) for c in k)
        codeasci='&#'+y+';'
        return codeasci
def encodee(url):
        asciicode=replace_ascii(url)
        basecode=base64.b64encode(asciicode.encode('ascii'))
        # print (str(basecode).replace("b'", '').replace("'", '').replace(" ", ''))
        return str(basecode).replace("b'", '').replace("'", '').replace(" ", '')
def decodee(url):
        decod_et = str(url).replace("b'", '').replace("'", '')
        # print (html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", '')))
        return html.unescape(str((base64.b64decode(str(decod_et)))).replace("b'", '').replace("'", ''))
######################################

def replace_fix(x):
        # x=x.replace('\\xc3\\xa7', 'ç').replace('\\xc3\\x87', 'Ç').replace('\\xc4\\x9f', 'ğ').replace('\\xc4\\x9e', 'Ğ').replace('\\xc4\\xb1', 'ı').replace('\\xc4\\xb0', 'İ').replace('\\xc5\\x9f', 'ş').replace('\\xc5\\x9e', 'Ş').replace('\\xc3\\xb6', 'ö').replace('\\xc3\\x96', 'Ö').replace('\\xc3\\xbc', 'ü').replace('\\xc3\\x9c', 'Ü').replace('\\x80\\x99','\'').replace('\\xf6',"ö").replace('\\xf0',"ğ").replace('\\xfc',"ü").replace('\\xfd',"ı").replace('\\xe7',"ç").replace('\\xfe',"ş").replace('\\xd6',"Ö").replace('\\xc7',"Ç").replace('\\xdd',"İ").replace('\\xde',"Ş").replace('\\xdc',"Ü").replace('\\xe2',"â").replace('\\u011f', 'ğ').replace('\\u011e', 'Ğ').replace('\\u0131', 'ı').replace('\\u0130', 'İ').replace('\\u015f', 'ş').replace('\\u015e', 'Ş').replace('Ã§', 'ç').replace('Ã‡', 'Ç').replace('ÄŸ', 'ğ').replace('Ä±', 'ı').replace('Ä°', 'İ').replace('Ã–', 'Ş').replace('ÅŸ', 'ö').replace('Ã¼', 'ü').replace('Ãœ', 'Ü').replace('Å&Yuml;', 'ş').replace('Åž', 'Ş').replace('Ã&Dagger;', 'Ç').replace('Ãoe', 'Ü').replace('Ã¶', 'ö').replace('Ã&ndash;', 'Ö').replace('Ä&Yuml;', 'ğ').replace('â&euro;&rdquo;', '—').replace('&amp;', '&').replace('&quot;', '\"').replace('&rsquo;', '\'').replace('&nbsp;', " ").replace('&uuml;', 'ü').replace('&ccedil;', "ç").replace('&ouml;', 'ö').replace('&acirc;', 'a').replace("&ldquo;","").replace("&ndash;","O").replace("%2F","/").replace("%3F","?").replace("%3D","=").replace("%26","&").replace("%2A","*")
        
        x=x.replace('\\xc2\\xa0',' ').replace('\\xc3\\xa7','c').replace('\\xe2\\x80\\x93',' - ').replace('\\xc4\\xb1','i').replace('\\xc3\\xb6','o').replace('xc3\\xbc','u').replace('xc5\\x9f','s').replace('\\xc5\\x9e','S').replace('xc4\\x9f','g').replace('\\xc3\\x87','C').replace('\\xc3\\x96','O').replace('\\xc3\\x9c','U').replace('\\xc2\\xa1','¡').replace('\\xc2\\xa2','¢').replace('&#039;','`').replace('\\xc2\\xa3','£').replace('\\xc2\\xa4','¤').replace('\\xc2\\xa5','¥').replace('\\xc2\\xa6','¦').replace('\\xc2\\xa7','§').replace('\\xc2\\xa8','¨').replace('\\xc2\\xa9','©').replace('\\xc2\\xaa','ª').replace('\\xc2\\xab','«').replace('\\xc2\\xac','¬').replace('\\xc2\\xad','­').replace('\\xc2\\xae','®').replace('\\xc2\\xaf','¯').replace('\\xc2\\xb0','°').replace('\\xc2\\xb1','±').replace('\\xc2\\xb2','²').replace('\\xc2\\xb3','³').replace('\\xc2\\xb4','´').replace('\\xc2\\xb5','µ').replace('\\xc2\\xb6','¶').replace('\\xc2\\xb7','·').replace('\\xc2\\xb8','¸').replace('\\xc2\\xb9','¹').replace('\\xc2\\xba','º').replace('\\xc2\\xbb','»').replace('\\xc2\\xbc','¼').replace('\\xc2\\xbd','½').replace('\\xc2\\xbe','¾').replace('\\xc2\\xbf','¿').replace('\\xc3\\x80','À').replace('\\xc3\\x81','Á').replace('\\xc3\\x82','Â').replace('\\xc3\\x83','Ã').replace('\\xc3\\x84','Ä').replace('\\xc3\\x85','Å').replace('\\xc3\\x86','Æ').replace('\\xc3\\x87','Ç').replace('\\xc3\\x88','È').replace('\\xc3\\x89','É').replace('\\xc3\\x8a','Ê').replace('\\xc3\\x8b','Ë').replace('\\xc3\\x8c','Ì').replace('\\xc3\\x8d','Í').replace('\\xc3\\x8e','Î').replace('\\xc3\\x8f','Ï').replace('\\xc3\\x90','Ð').replace('\\xc3\\x91','Ñ').replace('\\xc3\\x92','Ò').replace('\\xc3\\x93','Ó').replace('\\xc3\\x94','Ô').replace('\\xc3\\x95','Õ').replace('\\xc3\\x96','Ö').replace('\\xc3\\x97','×').replace('\\xc3\\x98','Ø').replace('\\xc3\\x99','Ù').replace('\\xc3\\x9a','Ú').replace('\\xc3\\x9b','Û').replace('\\xc3\\x9c','Ü').replace('\\xc3\\x9d','Ý').replace('\\xc3\\x9e','Þ').replace('\\xc3\\x9f','ß').replace('\\xc3\\xa0','à').replace('\\xc3\\xa1','á').replace('\\xc3\\xa2','â').replace('\\xc3\\xa3','ã').replace('\\xc3\\xa4','ä').replace('\\xc3\\xa5','å').replace('\\xc3\\xa6','æ').replace('\\xc3\\xa7','ç').replace('\\xc3\\xa8','è').replace('\\xc3\\xa9','é').replace('\\xc3\\xaa','ê').replace('\\xc3\\xab','ë').replace('\\xc3\\xac','ì').replace('\\xc3\\xad','í').replace('\\xc3\\xae','î').replace('\\xc3\\xaf','ï').replace('\\xc3\\xb0','ð').replace('\\xc3\\xb1','ñ').replace('\\xc3\\xb2','ò').replace('\\xc3\\xb3','ó').replace('\\xc3\\xb4','ô').replace('\\xc3\\xb5','õ').replace('\\xc3\\xb6','ö').replace('\\xc3\\xb7','÷').replace('\\xc3\\xb8','ø').replace('\\xc3\\xb9','ù').replace('\\xc3\\xba','ú').replace('\\xc3\\xbb','û').replace('\\xc3\\xbc','u').replace('\\xc3\\xbd','ý').replace('\\xc3\\xbe','þ').replace('\\xc3\\xbf','ÿ').replace('\\xc4\\x80','Ā').replace('\\xc4\\x81','ā').replace('\\xc4\\x82','Ă').replace('\\xc4\\x83','ă').replace('\\xc4\\x84','Ą').replace('\\xc4\\x85','ą').replace('\\xc4\\x86','Ć').replace('\\xc4\\x87','ć').replace('\\xc4\\x88','Ĉ').replace('\\xc4\\x89','ĉ').replace('\\xc4\\x8a','Ċ').replace('\\xc4\\x8b','ċ').replace('\\xc4\\x8c','Č').replace('\\xc4\\x8d','č').replace('\\xc4\\x8e','Ď').replace('\\xc4\\x8f','ď').replace('\\xc4\\x90','Đ').replace('\\xc4\\x91','đ').replace('\\xc4\\x92','Ē').replace('\\xc4\\x93','ē').replace('\\xc4\\x94','Ĕ').replace('\\xc4\\x95','ĕ').replace('\\xc4\\x96','Ė').replace('\\xc4\\x97','ė').replace('\\xc4\\x98','Ę').replace('\\xc4\\x99','ę').replace('\\xc4\\x9a','Ě').replace('\\xc4\\x9b','ě').replace('\\xc4\\x9c','Ĝ').replace('\\xc4\\x9d','ĝ').replace('\\xc4\\x9e','Ğ').replace('\\xc4\\x9f','g').replace('\\xc4\\xa0','Ġ').replace('\\xc4\\xa1','ġ').replace('\\xc4\\xa2','Ģ').replace('\\xc4\\xa3','ģ').replace('\\xc4\\xa4','Ĥ').replace('\\xc4\\xa5','ĥ').replace('\\xc4\\xa6','Ħ').replace('\\xc4\\xa7','ħ').replace('\\xc4\\xa8','Ĩ').replace('\\xc4\\xa9','ĩ').replace('\\xc4\\xaa','Ī').replace('\\xc4\\xab','ī').replace('\\xc4\\xac','Ĭ').replace('\\xc4\\xad','ĭ').replace('\\xc4\\xae','Į').replace('\\xc4\\xaf','į').replace('\\xc4\\xb0','I').replace('\\xc4\\xb1','ı').replace('\\xc4\\xb2','Ĳ').replace('\\xc4\\xb3','ĳ').replace('\\xc4\\xb4','Ĵ').replace('\\xc4\\xb5','ĵ').replace('\\xc4\\xb6','Ķ').replace('\\xc4\\xb7','ķ').replace('\\xc4\\xb8','ĸ').replace('\\xc4\\xb9','Ĺ').replace('\\xc4\\xba','ĺ').replace('\\xc4\\xbb','Ļ').replace('\\xc4\\xbc','ļ').replace('\\xc4\\xbd','Ľ').replace('\\xc4\\xbe','ľ').replace('\\xc4\\xbf','Ŀ').replace('\\xc5\\x80','ŀ').replace('\\xc5\\x81','Ł').replace('\\xc5\\x82','ł').replace('\\xc5\\x83','Ń').replace('\\xc5\\x84','ń').replace('\\xc5\\x85','Ņ').replace('\\xc5\\x86','ņ').replace('\\xc5\\x87','Ň').replace('\\xc5\\x88','ň').replace('\\xc5\\x89','ŉ').replace('\\xc5\\x8a','Ŋ').replace('\\xc5\\x8b','ŋ').replace('\\xc5\\x8c','Ō').replace('\\xc5\\x8d','ō').replace('\\xc5\\x8e','Ŏ').replace('\\xc5\\x8f','ŏ').replace('\\xc5\\x90','Ő').replace('\\xc5\\x91','ő').replace('\\xc5\\x92','Œ').replace('\\xc5\\x93','œ').replace('\\xc5\\x94','Ŕ').replace('\\xc5\\x95','ŕ').replace('\\xc5\\x96','Ŗ').replace('\\xc5\\x97','ŗ').replace('\\xc5\\x98','Ř').replace('\\xc5\\x99','ř').replace('\\xc5\\x9a','Ś').replace('\\xc5\\x9b','ś').replace('\\xc5\\x9c','Ŝ').replace('\\xc5\\x9d','ŝ').replace('\\xc5\\x9e','Ş').replace('\\xc5\\x9f','s').replace('\\xc5\\xa0','Š').replace('\\xc5\\xa1','š').replace('\\xc5\\xa2','Ţ').replace('\\xc5\\xa3','ţ').replace('\\xc5\\xa4','Ť').replace('\\xc5\\xa5','ť').replace('\\xc5\\xa6','Ŧ').replace('\\xc5\\xa7','ŧ').replace('\\xc5\\xa8','Ũ').replace('\\xc5\\xa9','ũ').replace('\\xc5\\xaa','Ū').replace('\\xc5\\xab','ū').replace('\\xc5\\xac','Ŭ').replace('\\xc5\\xad','ŭ').replace('\\xc5\\xae','Ů').replace('\\xc5\\xaf','ů').replace('\\xc5\\xb0','Ű').replace('\\xc5\\xb1','ű').replace('\\xc5\\xb2','Ų').replace('\\xc5\\xb3','ų').replace('\\xc5\\xb4','Ŵ').replace('\\xc5\\xb5','ŵ').replace('\\xc5\\xb6','Ŷ').replace('\\xc5\\xb7','ŷ').replace('\\xc5\\xb8','Ÿ').replace('\\xc5\\xb9','Ź').replace('\\xc5\\xba','ź').replace('\\xc5\\xbb','Ż').replace('\\xc5\\xbc','ż').replace('\\xc5\\xbd','Ž').replace('\\xc5\\xbe','ž').replace('\\xc5\\xbf','ſ').replace('\\x80\\x99','\'')
        return x
def xttplaymac(FILENAME,name,method,url,thumbnail,thumbfolder,fix,macinfo,cokinfo,headersinfo,actionplayer):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&fileName="+urllib.parse.quote_plus(FILENAME)+"&fix="+urllib.parse.quote_plus(fix)+"&macinfo="+urllib.parse.quote_plus(macinfo)+"&cokinfo="+urllib.parse.quote_plus(cokinfo)+"&headersinfo="+urllib.parse.quote_plus(headersinfo)+"&actionplayer="+urllib.parse.quote_plus(actionplayer)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"Title": name })
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    if method != "":
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        # return ok
    else:
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
def login():
    return True
    # try:
        # insidexttmc()
        # xttmc=htmlp.unescape(base64.b64decode(stone))
        # datalogin = {
               # 'username': username,
               # 'password': password,
               # 'action':'do_login',
               # }
        # getlog=net.http_POST(xttmc, datalogin).content.encode('utf-8', 'ignore')
        # if '>'+username+'<' in getlog:
            # return True
        # else:
            # hataxttmc()
            # return playList.clear(exit())
    # except:
        # try:
            # userpass=re.search('\#>xtt<\#(.*?)\#>xtt<\#', str(getlog)).group(1)
            # if userpass in getlog:
                # return True
            # else:
                # pass
        # except:
            # hataxttmc()
            # return playList.clear(exit())
def insidexttmc():
    if password == "":
        __settings__.openSettings()
        if password == "":
            return playList.clear(exit())
    else:
        return
def hataxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC BAGLANTI HATASI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC[/B][/COLOR]','  [COLOR yellow][B]Bilgilerinizi dogru girdiginizden emin olun ve tekrar giris yapmayi deneyin.[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]yada Hazir Degil[/COLOR][/B]","[COLOR gray][B]XTT Player Aktif[/B][/COLOR]")

################################################################################cp
def datacp():
    # return True
    insidecpxttmc()
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    keylog = __settings__.getSetting(decodee("JiMxMDg7JiMxMTE7JiMxMDM7JiMxMDU7JiMxMTA7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMTU7JiMxMDc7JiMxMjE7"))+"@"+__settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    r = requests.get(decodee(logdata), headers=headers)
    r.raise_for_status()
    rs = decodee(str(r.text))
    # print (rs)
    # print (str(json.loads(rs)['paneurl']))
    # js = str(json.loads(rs)['paneurl'][0]['datalog'])
    js = str(str(json.loads(rs)['keydata'])).strip('[]')
    match=re.compile('(?:\"|\')keylog(?:\"|\')\:\s*(?:\"|\')\>xttsky\<'+keylog+'\>xttsky\<(?:\"|\')').findall(str(js))
    if not match != []:
        hatacpxttmc()
        return playList.clear(exit())
    else: return True
    # try:
        # insidecpxttmc()
        # xttmc=htmlp.unescape(base64.b64decode(stone))
        # datalogin = {
               # 'username': username,
               # 'password': password,
               # 'action':'do_login',
               # }
        # getlog=net.http_POST(xttmc, datalogin).content.encode('utf-8', 'ignore')
        # if '>'+username+'<' in getlog:
            # cpwelcom = re.search('\#>xttmc<\#(.*?)\#>xttmc<\#', str(getlog)).group(1)
            # if cpwelcom in getlog:
                # return True
            # else:
                # hatauser()
                # return playList.clear(exit())
        # else:
            # return playList.clear(exit())
    # except:
        # try:
            # userpasscp=re.search('>xtt<(.*?)>xtt<', str(getlog)).group(1)
            # if userpasscp in getlog:
                # return True
            # else:
                # hatauser()
                # return playList.clear(exit())
        # except:
            # hatauser()
            # return playList.clear(exit())
def insidecpxttmc():
    datalog = __settings__.getSetting(decodee("JiMxMTI7JiM5NzsmIzExNTsmIzExNTsmIzEyMDsmIzExNjsmIzExNjsmIzExNTsmIzEwNzsmIzEyMTs="))
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        return
def hatacpxttmc():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTSKY KULLANICI UYELIK SORUNU..![/B][/COLOR]', '  [COLOR blue][B]LUTFEN GIRIS BILGILERINIZI KONTROL EDIN[/B][/COLOR]')
    __settings__.openSettings()
    return showMessage("[B][COLOR dimgray]Sorun mu Yasadiniz?[/COLOR][/B]","[COLOR gray][B]XTTSKY[/B][/COLOR]")
def hatauser():
    xbmcgui.Dialog().ok('[COLOR red][B]XTTMC UYARI..![/B][/COLOR]', '  [COLOR blue][B]XTTMC YÖNETİM[/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
def sifrehatasi():
    xbmcgui.Dialog().ok('[COLOR red][B]GİRİLEN ŞİFRE HATALI..![/B][/COLOR]', '  [COLOR blue][B]LÜTFEN ŞİFRENİZİ KONTROL EDEREK TEKRAR DENEYİNİZ..![/B][/COLOR]')
    # return showMessage("[B][COLOR dimgray]Girisiniz Yenilendi...[/COLOR][/B]","[COLOR gray][B]XTT Player[/B][/COLOR]")
################################################################################
def showMessage(str, header='', time=2000):
    try: xbmcgui.Dialog().notification(header, str, addon_icon, time, sound=False)
    except: xbmc.executebuiltin("Notification(%s,%s, %s, %s)" % (header, str, time, addon_icon))
##################### py ot okuyucu #######################
def loadImports(yol):
    files = os.listdir(yol)
    global imps
    imps = []
    for i in range(len(files)):
        py_name = files[i].split('.')
        if len(py_name) > 1:
            if py_name[1] == 'py' and py_name[0] != '__init__':
               py_name = py_name[0]
               imps.append(py_name)
    file = open(yol+'/__init__.py','w')
    toWrite = '__all__ = '+str(imps)
    file.write(toWrite)
    file.close()
    return imps
def listChannels(images_path):
    for FILENAME in imps:
        thumbnail= os.path.join(images_path, FILENAME+".png")
        if not thumbnail != "":
            thumbnail=thumbnail
        else:
            thumbnail=images_path+'/xttsmarttv.png'
        xttplaymac(FILENAME,FILENAME, "main()","",thumbnail,"","","","","")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
def listing(images_path,url):
    loadImports(url)
    listChannels(images_path)
######################################
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
params = get_params()
name = None
fileName = None
method = None
url = None
thumbnail = None
thumbfolder = None
fix = None
macinfo = None
cokinfo = None
headersinfo = None
actionplayer = None
try:
    name = urllib.parse.unquote_plus(params["name"])
except: pass
try:
    fileName = urllib.parse.unquote_plus(params["fileName"])
except: pass
try:
    method = urllib.parse.unquote_plus(params["method"])
except: pass
try:
    url = urllib.parse.unquote_plus(params["url"])
except: pass
try:
    thumbnail = urllib.parse.unquote_plus(params["thumbnail"])
except: pass
try:
    thumbfolder = urllib.parse.unquote_plus(params["thumbfolder"])
except: pass
try:
    fix = urllib.parse.unquote_plus(params["fix"])
except: pass
try:
    macinfo = urllib.parse.unquote_plus(params["macinfo"])
except: pass
try:
    cokinfo = urllib.parse.unquote_plus(params["cokinfo"])
except: pass
try:
    headersinfo = urllib.parse.unquote_plus(params["headersinfo"])
except: pass
try:
    actionplayer = urllib.parse.unquote_plus(params["actionplayer"])
except: pass
if fileName == None:
    main()
    listing(images_path,xtttest)
else:
    exec ("import "+fileName+" as channel")
    exec ("channel."+str(method))
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)