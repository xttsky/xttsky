# -*- coding: utf-8 -*-
import xbmcaddon,xttmcsrc
Addon = xbmcaddon.Addon(xttmcsrc.xttmcsrc_id)
FILENAME = "htmlxmltest"
'''#############################'''

# maininfohtmlxml = 'infoxml()' # XML
xttmcturkfilmxml = 'mainxml()' # XML
xttmckliphtmlxml = 'mainxml()' # XML
mainxttmctvxml = 'mainxml()' # XML
mainxtttvxml = 'xtttv.mainxml()' # XML
# '''#############################'''
maininfohtmlxml = 'infohtml()' # HTML
# xttmcturkfilmxml = 'mainhtml()' # HTML
# xttmckliphtmlxml = 'mainhtml()' # HTML
# mainxttmctvxml = 'mainhtml()' # HTML
# mainxtttvxml = 'xtttv.mainhtml()' # HTML
# aHR0cHM6Ly90d2l0dGVyLmNvbS9JemxlQWR1bHQ