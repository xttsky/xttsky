# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import xbmc
import xbmcplugin
import xbmcaddon
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
channels = xbmc.translatePath(os.path.join(home, 'channels'))
sys.path.append(channels)
# xtttest = xbmc.translatePath(os.path.join(home, 'channels','xtttest'))
# sys.path.append(xtttest)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon    = __settings__.getAddonInfo('icon')
import xttskytools
FILENAME = "xttsky"
def main():
    if (__name__ == '__main__' ):
        import skysmart
        skysmart.main()
######################################
# def get_params():
    # param=[]
    # paramstring=sys.argv[2]
    # if len(paramstring)>=2:
        # params=sys.argv[2]
        # cleanedparams=params.replace('?','')
        # if (params[len(params)-1]=='/'):
            # params=params[0:len(params)-2]
        # pairsofparams=cleanedparams.split('&')
        # param={}
        # for i in range(len(pairsofparams)):
            # splitparams={}
            # splitparams=pairsofparams[i].split('=')
            # if (len(splitparams))==2:
                # param[splitparams[0]]=splitparams[1]
    # return param
    # return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
# params = get_params()
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
try: name = urllib.parse.unquote_plus(params["name"])
except: name = None
try: fileName = urllib.parse.unquote_plus(params["fileName"])
except: fileName = None
try: method = urllib.parse.unquote_plus(params["method"])
except: method = None
try: url = urllib.parse.unquote_plus(params["url"])
except: url = None
try: thumbnail = urllib.parse.unquote_plus(params["thumbnail"])
except: thumbnail = None
try: thumbfolder = urllib.parse.unquote_plus(params["thumbfolder"])
except: thumbfolder = None
try: fix = urllib.parse.unquote_plus(params["fix"])
except: fix = None
try: mac = urllib.parse.unquote_plus(params["mac"])
except: mac = None
try: timezone = urllib.parse.unquote_plus(params["timezone"])
except: timezone = None
try: tokenkey = urllib.parse.unquote_plus(params["tokenkey"])
except: tokenkey = None
try: playinfo = urllib.parse.unquote_plus(params["playinfo"])
except: playinfo = None
try: metainfo = urllib.parse.unquote_plus(params["metainfo"])
except: metainfo = None
if fileName == None:
    main()
    # listing(images_path,xtttest)
else:
    exec ("import "+fileName+" as channel")
    exec ("channel."+str(method))
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)